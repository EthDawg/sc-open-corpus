---
title: "Success Plans"
description: "The CSM/A way of working for success plans: every customer request and workstream gets a work item in the success plan project, and every work item follows the same structure."
---

View the [CSM Handbook homepage](/handbook/customer-experience/csm/) for additional CSM-related handbook pages.

---

## Why we work this way

The success plan is the single source of truth for every account. When the work lives in one place, the customer, the account team, and anyone at GitLab can see where things stand and what changed for the customer.

Without it, context ends up scattered across Slack, email, documents, and memory. That makes it easy to lose track of a customer when you manage many accounts. It also means scrambling for technical detail during an escalation, rebuilding an account from scratch at handoff, and reporting that doesn't reflect reality. A lot of the value we deliver for customers also goes undocumented.

When you do the work in the success plan once, it feeds everything else:

- **Meeting prep:** agendas built from real open items.
- **Handoffs:** the full history of the account, not someone's memory.
- **Health snapshots and manager reporting:** engagement and health based on documented work.
- **EBRs and renewals:** backed by a documented record of outcomes.
- **Verifiable Outcomes:** wins are surfaced and tracked, not buried in a thread.
- **Everyone at GitLab:** Product, Engineering, Sales, Solutions Architects, and Professional Services can open an account's history without a separate briefing.
- **AI tools:** structured, focused context that tools such as GitLab Duo Agent Platform (DAP) and the CSM/A Assistant can search, instead of scattered notes.

The result is better customer outcomes: action items are documented, recommendations and answers are recorded, and follow-ups are managed in the open.

## Every request and workstream gets a work item

A success plan is the roadmap for achieving a customer's business objectives using GitLab. It lives in the customer's success plan project, and it is built from work items: one for every customer request and every workstream.

Think of it like Zendesk. A customer asks, you open the ticket, send them the link, and work it there. Workstreams, also called initiatives, work the same way.

For the deliverables that every success plan must include, such as Executive Business Reviews (EBRs), workshops, and Verifiable Outcomes (VOs), see [Success plan deliverables](/handbook/customer-experience/csm/success-plans/deliverables/).

## How it works

1. **A request comes in.** This can be a customer request by Slack, email, or another channel, a new workstream (initiative), a call transcript, or your own notes.
1. **Open an issue.** The issue is your ticket for the request.
1. **Send the link back.** Share the issue with the customer.
1. **Collaborate in the issue.** Every update and collaboration lives there. Emails can be exchanged in the issue.

For Slack conversations, post a screenshot of the conversation to the issue so the history stays with the work item.

### Keep logging simple

The success plan project is meant for the customer first. Open a work item for each real request or workstream, not for every email, task, or meeting. Add follow-up activity as comments on the existing work item, and close work items when they are done.

The number of work items depends on the customer, but even a large, complex account should have a focused set of open work items, not hundreds.

## The four parts of every work item

Every issue has the same four parts. For example, an issue might cover runner observability, or a customer question about SAST and DAST testing.

| Part | Where it lives | What it contains |
|---|---|---|
| 1. **Summary** | Issue description | What the workstream is, in plain English, with links to issues, tickets, and docs. |
| 2. **Success Criteria** | Issue description | What "done" looks like, in outcomes the customer would recognize. |
| 3. **DRI** | Issue description | The one person who owns it, by `@handle`. |
| 4. **Comment update** | New comment | Added after every call, email, or Slack thread. |

### Refresh: where things stand now

Parts 1 to 3 live at the top of the issue. Edit them as the work changes so anyone can open the issue cold and understand it.

### Add: what happened

Part 4 is a new comment after every interaction. The thread becomes the history of the workstream. Each comment update includes:

- **A heading:** the customer, the topic, and the date of the interaction.
- **Attendees:** who attended from the customer and from GitLab, with their roles.
- **Meeting summary:** what was discussed, what was decided, and what is still open. Link to earlier comments or related issues for context.
- **Next steps:** each action with an owner and timing. `@`-mention the customer on each action they own. Record decisions and risks here too.

### Work item templates

Start every work item from one of the success plan (`sp-`) issue templates. They are maintained in the [sub-group issue templates project](https://gitlab.com/gitlab-com/account-management/sub-group-issue-templates/-/tree/master/.gitlab/issue_templates), and each one already includes the Summary and Success Criteria sections.

| Template | Use it for |
|---|---|
| [`sp-success-general-planning-issue`](https://gitlab.com/gitlab-com/account-management/sub-group-issue-templates/-/blob/master/.gitlab/issue_templates/sp-success-general-planning-issue.md) | Most customer requests and workstreams. Start here if no other template fits. |
| [`sp-accelerator-initiative-epic`](https://gitlab.com/gitlab-com/account-management/sub-group-issue-templates/-/blob/master/.gitlab/issue_templates/sp-accelerator-initiative-epic.md) | The epic for a Success Accelerator. |
| [`sp-accelerator-initiative-general`](https://gitlab.com/gitlab-com/account-management/sub-group-issue-templates/-/blob/master/.gitlab/issue_templates/sp-accelerator-initiative-general.md) | An initiative issue under a Success Accelerator, including technical environment discovery. |
| [`sp-dap-activation`](https://gitlab.com/gitlab-com/account-management/sub-group-issue-templates/-/blob/master/.gitlab/issue_templates/sp-dap-activation.md) | The customer-facing plan for Duo Agent Platform (DAP) onboarding and activation. |
| [`sp-dap-consumption-plan-internal`](https://gitlab.com/gitlab-com/account-management/sub-group-issue-templates/-/blob/master/.gitlab/issue_templates/sp-dap-consumption-plan-internal.md) | The internal-only DAP consumption plan. Never make this issue visible to the customer. |
| [`sp-ebr-planning`](https://gitlab.com/gitlab-com/account-management/sub-group-issue-templates/-/blob/master/.gitlab/issue_templates/sp-ebr-planning.md) | Planning an [Executive Business Review (EBR)](/handbook/customer-experience/csm/success-plans/deliverables/#executive-business-reviews-ebrs). |
| [`sp-feature_request`](https://gitlab.com/gitlab-com/account-management/sub-group-issue-templates/-/blob/master/.gitlab/issue_templates/sp-feature_request.md) | A customer feature request. |
| [`sp-workshop-planning`](https://gitlab.com/gitlab-com/account-management/sub-group-issue-templates/-/blob/master/.gitlab/issue_templates/sp-workshop-planning.md) | Planning a [workshop](/handbook/customer-experience/csm/success-plans/deliverables/#workshops). |

### Comment update format

Use this structure for each comment update:

```markdown
### [Customer] | [Topic] Sync - [Month DD, YYYY]

**Attendees ([Customer]):** [Name] ([Role]), [Name] ([Role])

**Attendees (GitLab):** [Name] ([Role]), [Name] ([Role])

[Meeting type, such as a weekly cadence call or an async Slack thread. Link to the previous related comment or issue for context.]

[Meeting summary: what was discussed, what was decided, and what is still open. Write in plain language for someone who was not there.]

**Next Steps:**

- [ ] Action ([Name] @handle, [timing]): [What needs to happen]
- [ ] Action ([Customer name] @customer-handle, [timing]): [What the customer owns]
- [ ] Risk: [Anything that could block or change the outcome]
- [ ] Blocker: [Anything currently preventing progress, and who can unblock it]
- [ ] Question: [Anything open that needs an answer, and who needs to answer it]
- Decision: [Anything agreed during the interaction]
```

When an action carries over from an earlier interaction, repeat it in the new comment and link to the comment where it started. Check off actions as they are delivered.

## Project baseline

Every success plan project needs to meet these baseline checks. You can run them at any time with the `project-baseline` skill in the [CSM/A Assistant](#tools-and-help).

1. **Members are Guest, not higher.** Downgrade any direct member with a role above Guest. Check group-level access manually, because no tool covers that layer.
1. **No duplicate project is left open.** Keep the project that matches the naming convention, or the one with more open activity, and archive the other.
1. **The wiki and README match the template.** Don't leave blank wiki pages or `[SQUARE BRACKET]` placeholders in the README.

## Success plan lifecycle

Success plans span the full customer journey. Here is where the CSM's role fits in:

| Phase | Who leads | What happens |
|---|---|---|
| **Pre-sales** | SA + AE | Customer objectives are documented and used to demonstrate GitLab value. See the [mutual customer success plan process](/handbook/solutions-architects/processes/customer-success-plan/). |
| **Post-sales / Onboarding** | CSM | CSM reviews objectives, validates accuracy, and adds initiatives for enablement and implementation. Full alignment on what comes next and who owns it. |
| **Ongoing engagement** | CSM | Success plan anchors every [cadence call](/handbook/customer-experience/csm/cadence-calls/) and [business review](/handbook/customer-experience/csm/ebr/). Cadence calls drive week-to-week progress; business reviews assess strategy and surface new objectives. |

For discovery questions that help you build a success plan, see [Questions & Techniques for Success Plan Discovery](/handbook/customer-experience/csm/success-plans/questions-techniques/).

## Gainsight

The success plan is the single source of truth. Gainsight reflects it and enables pattern analysis across the full book of business.

EBRs and workshops are planned and tracked in the success plan. For now, also log them in Gainsight once they are delivered. See [Success plan deliverables](/handbook/customer-experience/csm/success-plans/deliverables/) for details.

For detailed guidance on Gainsight workflows, see [Using Gainsight as a CSM](/handbook/customer-experience/csm/gainsight/).

## Tools and help

The CSM/A Assistant is a plugin for the Claude desktop app. It doesn't work on the claude.ai website. To install and set it up, see the [CSM/A Assistant plugin](https://gitlab.com/gitlab-com/marketplace/-/tree/main/sales/customer-experience/customer-success/csma) in the GitLab Claude plugin marketplace.

For questions, ask in the [`#cx-collab-proj-success-plan-questions`](https://gitlab.enterprise.slack.com/archives/C0BFC7KLA3V) Slack channel.
