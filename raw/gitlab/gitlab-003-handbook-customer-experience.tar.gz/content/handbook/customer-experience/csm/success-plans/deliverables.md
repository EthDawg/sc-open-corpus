---
title: "Success Plan Deliverables"
description: "The deliverables CSMs and CSAs provide through every customer success plan: Executive Business Reviews, workshops, Verifiable Outcomes, and a standard way of working."
---

View the [CSM Handbook homepage](/handbook/customer-experience/csm/) for additional CSM-related handbook pages.

---

Every success plan includes the deliverables on this page. As a CSM or CSA, you are responsible for providing each of them to your customers.

| Deliverable | Where it is tracked |
|---|---|
| [Standard way of working](#standard-way-of-working) | Success plan project |
| [Executive Business Reviews (EBRs)](#executive-business-reviews-ebrs) | Success plan project, and also logged in Gainsight |
| [Workshops](#workshops) | Success plan project, and also logged in Gainsight |
| [Verifiable Outcomes (VOs)](#verifiable-outcomes-vos) | Success plan project, as epics |
| [Accelerators](#success-accelerators-csas-only) | Success plan project, as epics |

The success plan is the single source of truth for every deliverable. Some deliverables also need a record in Gainsight for now, but the work is planned and tracked in the success plan.

## Standard way of working

Every success plan follows the same way of working, so anyone can open a customer's success plan and understand it. Every customer request and workstream gets a work item, and every work item has the same four parts: a Summary, Success Criteria, a DRI, and a comment update after every interaction.

For the full process and templates, see [Success Plans](/handbook/customer-experience/csm/success-plans/).

## Executive Business Reviews (EBRs)

EBRs are part of the success plan. Plan each EBR as an issue in the success plan project, using the [`sp-ebr-planning` template](https://gitlab.com/gitlab-com/account-management/sub-group-issue-templates/-/blob/master/.gitlab/issue_templates/sp-ebr-planning.md). For now, also log them in Gainsight once delivered.

For guidance on planning and running an EBR, see [Executive Business Reviews (EBRs)](/handbook/customer-experience/csm/ebr/).

## Workshops

Workshops are part of the success plan. Plan each workshop as an issue in the success plan project, using the [`sp-workshop-planning` template](https://gitlab.com/gitlab-com/account-management/sub-group-issue-templates/-/blob/master/.gitlab/issue_templates/sp-workshop-planning.md). For now, also log them in Gainsight once delivered.

For guidance on running workshops and logging them, see [Workshops and Enablement Sessions](/handbook/customer-experience/csm/workshops/).

## Success Accelerators (CSA's Only) 

Success Accelerators are structured, outcome-focused engagements that help customers achieve specific goals faster. Each accelerator is planned as an epic in the success plan project and follows the same structure as a Verifiable Outcome.

You are responsible for Success Accelerators: 

- Be an epic, or an issue promoted to an epic.
- Have the `Success Accelerator` label 

## Verifiable Outcomes (VOs)

A Verifiable Outcome (VO) is a customer objective that is formally tracked and validated by the customer. A VO must be [SMART](#what-makes-a-good-vo).

### Track Verifiable Outcomes

You are responsible for VO labeling in the success plan project. Each VO must:

- Be an epic, or an issue promoted to an epic.
- Have a `~Verifiable Outcome::` label with one of the values in the following table.
- Have an end date.

All other label requirements are deprecated.

| Stage | Label | When to apply |
|---|---|---|
| **Proposed** | `~Verifiable Outcome::Proposed` | VO identified; drafting internally before customer presentation |
| **Accepted** | `~Verifiable Outcome::Accepted` | Customer aligned on objective, baseline, success criteria, and timeline |
| **Delivered** | `~Verifiable Outcome::Delivered` | Work complete on GitLab's side |
| **Verified** | `~Verifiable Outcome::Verified` | Customer has explicitly confirmed successful completion *(preferred)* |

These labels are nice to have, but not required:

- `~UseCase::`
- `~Support::Assigned Support Engineer`
- `~SKU::Professional Services`
- Feature request labels

### Promote an issue to an epic

If you already have an issue that should be tracked as a VO, promote it to an epic using one of two methods.

To promote an issue in the UI:

1. Open the issue.
1. In the upper-right corner, select **More actions** (**⋮**) > **Change type**.
1. Under **Type**, select **Epic**.
1. Select **Change type**.

To promote an issue with a quick action, add a comment on the issue with:

```text
/promote_to Epic
```

Either method creates an epic in the issue's parent group and carries over the title, description, comments, participants, and relevant group labels. After promotion, verify that the `~Verifiable Outcome::` label and the end date are present.

### What makes a good VO?

A VO must be **SMART**: Specific, Measurable, Attainable, Relevant, Time-bound.

Every VO needs: a **baseline** (where you are today), **success criteria** (how you'll know you're done), **business impact** (in the customer's language), and a **timeline**.

**Within-quarter VO examples:**

| VO | Baseline | Success Criteria | Timeframe | Business Impact |
|---|---|---|---|---|
| Security and engineering leads are equipped to enforce compliance policies in their pipelines | Team has not used Compliance Pipelines; no enforced policy framework in place | Security and engineering leads attend compliance policies workshop; customer confirms understanding of the policy enforcement model and identifies at least one policy to implement | Within the quarter | Gives the team a concrete starting point for enforcing standards; reduces reliance on individual developer behavior for compliance |
| Platform team is actively using DAP capabilities they already own | DAP capabilities are not in use; available promotional credits are undeployed | Top 5 DAP use cases reviewed with the platform team; promotional credits applied or a deployment plan confirmed | Within the quarter | Turns an underutilized purchase into active value; reduces time to first meaningful DAP adoption |
| New development team has their first pipelines running in GitLab | New team of 12 developers has no CI/CD pipelines in GitLab | All 12 developers have at least one pipeline running in their project; team can build and troubleshoot basic pipelines without CSM support | Within the quarter | Unblocks the team from manual deployment steps; establishes the foundation for broader CI/CD adoption |
| Pilot group has hands-on experience with GitLab Duo and a clear next step | No Duo usage in the account; pilot group identified but not yet enabled | Pilot group enabled and has completed at least one use case walkthrough; customer has provided feedback and confirmed whether to expand, pause, or adjust the rollout | Within the quarter | Converts an unknown into a decision; gives the customer a concrete basis for their next Duo investment choice |
| Customer's main branch pipeline failure rate is no longer blocking releases | ~30% failure rate on main branch causing release delays | Pipeline failure rate reduced to under 5%; root cause documented and shared with customer engineering lead | Within the quarter | Restores release velocity; eliminates a recurring source of developer frustration and lost time |

**Discovery tips:**

- Ask open-ended TED questions: *"Tell me about your team's priorities... Explain how... Describe what..."*
- Reference investor reports, press releases, and GitLab case studies to frame business impact
- Use GitLab Duo to test whether your criteria are truly SMART

For additional discovery questions and techniques, see [Questions & Techniques for Success Plan Discovery](/handbook/customer-experience/csm/success-plans/questions-techniques/).
