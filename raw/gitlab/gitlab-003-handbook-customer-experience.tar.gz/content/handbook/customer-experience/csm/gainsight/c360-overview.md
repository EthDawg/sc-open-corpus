---
title: "Customer 360"
description: "An overview of the key components in Customer 360."
---

*For an overview of Gainsight, and information about how to login, please refer to the [Gainsight Overview Page](/handbook/sales/gainsight/).*

For an overview of how CSMs use Gainsight, please refer to the [Gainsight CSM Overview Page](/handbook/customer-experience/csm/gainsight)

## Customer 360

The Customer 360 (or C360) is the full overview for each individual account.

The left side panel of the 360 contains the following sections:

- Summary - high-level overview of the account
- Attributes - account-related details and links; for lifecycle stage definitions, see our [vision handbook page](/handbook/customer-experience/customer-success-vision/#lifecycle-stages), and for deployment types see our [definitions](/handbook/customer-experience/csm/gainsight/deployment-types/)
- Scorecard - [health score](/handbook/customer-experience/csm/health-score-triage/)
- Success Plan - [success plans](/handbook/customer-experience/csm/success-plans/)
- Account Hierarchy - provides a tree of parent and child account hierarchy if applicable
- Cockpit - holds all of your tasks and [CTAs](/handbook/customer-experience/csm/gainsight/ctas/) for the account
- Contacts - all contacts for the account ([synced from Salesforce](/handbook/customer-experience/csm/gainsight/#salesforce-and-zendesk-syncing))
- Opportunities - open opportunities ([synced from Salesforce](/handbook/customer-experience/csm/gainsight/#salesforce-and-zendesk-syncing))
- License Utilization - [license utilization](/handbook/customer-experience/product-usage-data/use-case-adoption/)
- Product Usage Trends - [product usage trends](/handbook/customer-experience/product-usage-data/using-product-usage-data-in-gainsight/#gainsight-reports-and-dashboards)
- Product Usage Scorecard Calcs - shows [calculations](/handbook/customer-experience/product-usage-data/use-case-adoption/) of product usage health score
- Instance and Namespace Details - [instance and namespace details](/handbook/customer-experience/product-usage-data/using-product-usage-data-in-gainsight/#gainsight-reports-and-dashboards)
- Whitespace (Use Case) - [use case technology tracking](/handbook/sales/understand-customer-gitlab-use/#use-case-technology-tracking)
- Whitespace (Use Case Visual) - visualization of inputs from above report
- Whitespace (Stages until transition) - tracks whitespace information based on stage
- Webinar Participants - gives insight into registrations / attendance for 1:many events (webinars, hands-on labs, etc)
- Survey - holds all survey response data from Journey Orchestrator customer programs
- Program Logs - automatically logs Journey Orchestrator customer program emails to the account history for visibility

If you'd like, you can toggle the "Scrolling" button at the top of any 360 page to enable scrolling through all of the sections, rather than having to click into them.

Note at the top of the 360 page, there is a button for [Timeline](/handbook/customer-experience/csm/gainsight/timeline/), which shows all logged activities for that specific customer. Gainsight has a number of options for logging a CSM's interactions with a customer. These are useful to build a historical record of what the customer has done with us, and the initiatives we've worked on.

### Following accounts

On each account's 360, there is a "Follow" button next to the account name. If you are assigned as a CSM to an account, there is no need to follow the account, as you will automatically receive all notifications for that account. If you are not the CSM assigned to an account, you can follow the account to receive the same notifications the CSM assigned does.

### Referenceable customers

The `Referenceable Customers` field on the C360 Attributes section highlights [if a customer is a Referenceable Customer](/handbook/marketing/growth-marketing/growth-community-programs/). If a Customer is *not* a Referenceable Customer and they would make a great one, follow the process to Nominate a Reference Customer.

### NPS and CSAT Scores

For information on customer surveys and how the NPS and CSAT scores are calculated and the types of questions asked, please refer to the [NPS and CSAT scores handbook page](/handbook/sales/field-operations/customer-success-operations/cs-ops-programs/nps-csat-scores/).
