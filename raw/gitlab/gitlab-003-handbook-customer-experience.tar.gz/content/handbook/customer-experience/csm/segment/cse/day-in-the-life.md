---
title: "A Day in the Life of a CSE"
description: "What a Customer Success Engineer's work looks like day to day across the three motions, how the team works, and how success is measured."
weight: 50
---

No two days are the same for a Customer Success Engineer (CSE), but most combine customer calls, preparation,
follow-up, work with the account team, and time on the team's webinars and labs. This page shows what that looks like
in practice. For the formal definition of the role, see the
[CSE job family](/job-description-library/sales/customer-success-engineer/).

## A typical day

### In the Pooled motion

The morning starts with a new request that came in overnight: a customer wants a 45-minute call on CI/CD pipeline
optimisation. You check with the Account Executive (AE) who raised it, then prepare: the customer's adoption trends,
their support ticket history and any earlier CSE work. You run the call, confirm the next steps before hanging up,
and send the follow-up email.

Later, you join a customer webinar as co-pilot, working the Q&A queue while a senior CSE presents.

### In the Assigned motion

You spend part of the morning on health assessments for three of your accounts. One shows CI adoption stalling after
a team change. You share it with the account team and agree who will reach out, and with what help.

### In the Onboarding motion

A customer that bought GitLab last week has booked their onboarding kickoff. You review what the AE captured during
the sale, then walk the customer through their Onboarding Hub, agree their goals for the year, and settle the pilot
team and the first 30 days of work.

## What ties it together

The principle is **scale**. A CSE's expertise reaches many customers, not a small set of named accounts. You work
efficiently, you work proactively, and you work with the account team, not instead of it.

## How the team works

The CSE team is global (AMER, EMEA and APJ), distributed and [async-first](/handbook/company/culture/all-remote/).
Much of the work, especially in the Assigned motion, happens behind the scenes with no customer-facing artifact to
point to. That makes how you document your work central to the role.

- **Speed with quality.** Move fast and learn faster, with the discipline that lets customers rely on our work. See
  GitLab's [operating principles](/handbook/company/operating-principles/#speed-with-quality).
- **Document by default.** If you figured something out, spotted a risk or made a decision on an account, write it
  down where the right people will find it. Undocumented work is, in practice, invisible work.
- **Be transparent and communicate early.** If your workload is building up in one motion at the expense of another,
  tell your manager. Surfacing tension early is expected, not a performance issue.
- **Prioritise deliberately.** When capacity is tight, agree priorities with your manager.
- **Ask early.** Asking a colleague or a product team is always encouraged, never a last resort.

## Recurring meetings

- **CSE All Hands:** a quarterly look at the team's achievements, progress and goals.
- **Field Enablement:** required sessions on important features, initiatives and releases.
- **Regional team meetings:** your local team's regular sync.
- **CSE Peer Review:** a team call to discuss cases, learn new topics and get questions answered live.
- **Office hours:** optional sessions with product experts on specific features.

## Beyond customer engagements

The role is bigger than the request queue. None of this is mandatory in your first 90 days, but it is where much of
the team's energy goes.

- **Webinars and labs.** CSEs present the [webinar and lab programme](/handbook/customer-experience/csm/segment/cse/webinars-and-labs/);
  the content itself is produced by the programme team. If customers keep asking about a topic that has no session,
  raise it.
- **Initiatives and working groups.** The team runs a rolling set of improvements to tooling, process, the handbook
  and enablement, tracked as work items and open to contribution. Commenting, reviewing a draft or testing a process
  change all count.
- **Lunch and Learn.** A recurring session on technical topics, such as reference architectures, Geo, Gitaly and CI
  components, shared across Customer Success and Professional Services. Once you build expertise in an area, it is a
  natural place to share it.
- **Sharing what you learn.** When something took you time to work out, write it up briefly and share it with the
  team. "Figured this out today, might save someone else the same time" is enough. Share interesting findings from
  customer calls too, anonymised where needed: pattern-sharing is how the team gets smarter together.
- **Helping colleagues.** Answer questions even when you are not the expert. "I don't know, but here's who does" is a
  valuable answer. Visibility in a distributed team is not about being loud; it is about being reliably present and
  consistently useful.
- **Field events.** As your confidence grows, you can represent the team at customer roundtables, user groups and
  regional GitLab events. You raise your hand, your manager endorses, and you take part when the moment is right.
  These opportunities are worth taking: direct customer conversations outside engagements are one of the fastest ways
  to build the market intuition that makes every later engagement sharper.

## How success is measured

There is no single metric for a good CSE. These matter most:

- **Adoption outcomes:** did the engagement move the customer's adoption of CI/CD, security, GitLab Duo or source
  code management?
- **Customer satisfaction:** customers receive a short survey after each engagement.
- **Quality of documentation:** clear records and outcomes are how the rest of the account team sees your work.
- **Health assessments** (Assigned motion): a quality quarterly assessment for each account, plus at least one
  customer touch per account per quarter.
- **Proactive help:** recognising early when a customer needs more support, such as Professional Services or a
  Success Tier, and connecting them with the account team.

## Related pages

- [CSE homepage](/handbook/customer-experience/csm/segment/cse/)
- [CSE team member onboarding](/handbook/customer-experience/csm/segment/cse/team-member-onboarding/)
