---
title: "How CSEs Run Customer Engagements"
description: "What happens before, during and after a CSE customer call, what CSEs do not do, and when a customer may need more than a CSE."
weight: 35
---

Calls with customers are not one size fits all, and neither are CSEs: the range of skills and expertise on the team
is its strength. This page sets out what a Customer Success Engineer (CSE) engagement includes, whichever
[motion](/handbook/customer-experience/csm/segment/cse/) it belongs to.

## Before the call

- **Align with the account team.** The CSE checks with the Account Executive (AE) or Renewals Manager (RM) on the ask
  and on how to reach the customer, and invites the account team to the call.
- **Research the account.** The CSE reviews the customer's GitLab usage, earlier engagements and recent support
  history, so the call starts from where the customer is.
- **Prepare questions, not a script.** The CSE comes with discovery questions and a few candidate solutions.
- **Recording.** Calls are recorded. When attendees join, they see a recording notice and can ask not to be recorded,
  and the CSE can stop the recording at any time.

## During the call

The CSE starts by confirming what the customer wants from the call, asks how their experience with GitLab has been,
and leads with discovery before jumping to solutions. Before closing, they confirm the next steps: what they are, who
owns each one, and by when.

## After the call

The CSE sends a summary email, with the account team copied, covering what was discussed, the recommendations with
links to the documentation, the follow-up items and who owns them, and any webinars or labs that may help. The email
invites the customer to reach out with further questions.

## What CSEs do not do

- **Break/fix and bugs** go to [GitLab Support](https://about.gitlab.com/support/).
- **Hands-on delivery.** CSEs give architecture, migration and implementation guidance and best practices. Hands-on
  delivery, such as running a migration or deploying an architecture, is a
  [Professional Services](https://about.gitlab.com/services/) engagement.
- **Ongoing advisory,** cadence calls and business reviews are part of the
  [Success Tiers](/handbook/customer-experience/success-services/).

### Signals a customer may need more than a CSE

A customer may benefit from a **Success Tier** when they:

- Want a regular cadence of calls.
- Have a defined roadmap for GitLab and want guidance along the way.
- Want follow-up on their feature requests.
- Ask for custom workshops or internal training beyond the webinar and lab programme.
- Keep coming back for help after individual engagements close.

A customer may benefit from **Professional Services** when they face:

- Tool fragmentation or consolidation.
- Compliance and security requirements.
- Skills gaps or limited capacity.
- Performance and scalability issues.
- Gaps in visibility and metrics.
- A migration or modernisation.
- Organisational change, a merger or an acquisition.
- Timeline pressure.

CSEs flag these signals to the account team, who take the conversation forward.
