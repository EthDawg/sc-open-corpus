---
title: "Customer Success Engineering"
description: "The Customer Success Engineering (CSE) team: what CSEs do, the three CSE motions, and how CSEs work with the account team."
---

Customer Success Engineers (CSEs) deliver GitLab's **On-Demand Success tier**: technical product expertise and
best-practice guidance to GitLab customers. CSEs work at scale: one-to-one engagements and onboarding for customers
who do not have a dedicated Customer Success Manager (CSM) or Customer Success Architect (CSA), and webinars and
hands-on labs open to everyone.

View the [CSM Handbook homepage](/handbook/customer-experience/csm/) for other Customer Success pages.

## What a CSE does

A CSE shows up with deep technical expertise, solves a specific problem or fills a specific knowledge gap, and hands
the customer back to their account team better equipped than before. As a CSE you are:

- **Technically focused.** The value you bring is product expertise, adoption guidance, and early sight of technical
  risk. Commercial strategy and renewals stay with the Account Executive (AE) and Renewals Manager (RM).
- **A named contact in the Assigned motion.** There, the CSE is the account's named technical contact and carries an
  ongoing relationship with the customer; commercial strategy and renewals still stay with the AE and RM.
- **Bounded in scope.** An engagement covers one topic and typically takes one to three interactions. CSEs do not run
  Executive Business Reviews (EBRs) or Quarterly Business Reviews (QBRs), and do not own success plans.
- **Working at scale.** One CSE covers many customers, so the work is built to scale: focused, repeatable
  engagements, usage data to see where help is needed most, and one-to-many webinars and labs alongside one-to-one
  work.
- **Part of the account team.** CSEs work with the AE, RM and Solutions Architect (SA), not instead of them.

### How CSE differs from CSM

A CSM builds and maintains a customer relationship over time, with a regular cadence, a success plan and business
reviews. That depth is part of GitLab's paid [Success Tiers](/handbook/customer-experience/success-services/):

- **Essentials:** a designated [CSM](/handbook/customer-experience/csm/) for adoption, success planning and renewal
  strategy.
- **Advanced:** a designated [CSA](/handbook/customer-experience/csm/segment/csa/) for deep technical enablement and
  Accelerator programs.
- **Signature:** a designated CSA plus an
  [Assigned Support Engineer (ASE)](/handbook/support/enhanced-support-offerings/offering-assigned-support-engineer/)
  for the highest level of white-glove support.

CSE coverage is included in the customer's subscription and does not replace a Success Tier. When a customer wants
ongoing advisory, recurring cadence calls or business reviews, the CSE flags it to the AE and RM as a Success Tier
conversation.

## The three CSE motions

CSEs cover customers through three motions.

| | [Assigned](/handbook/customer-experience/csm/segment/cse/cse-assigned/) | [Pooled](/handbook/customer-experience/csm/segment/cse/pooled/) | [Onboarding (First Order)](/handbook/customer-experience/csm/segment/cse/customer-onboarding/) |
| --- | --- | --- | --- |
| **Who it covers** | Qualifying accounts without a CSM or CSA | Qualifying accounts without a CSM or CSA, on request | Eligible new customers in their first year |
| **How it starts** | Proactively, no request needed | The account team requests a CSE | With a welcome email when the first purchase closes; the customer books their kickoff |
| **Relationship** | A named CSE for each account | The next available CSE from a shared team | A CSE through the first year |
| **Cadence** | A quarterly health assessment and at least one customer touch each quarter | Per request | Kickoff, then check-ins at 30 days, 90 days, 6, 9 and 12 months |
| **Mode** | Proactive | Reactive | Proactive |

Alongside the three motions, the team participates in hosting [webinars and hands-on labs](/handbook/customer-experience/csm/segment/cse/webinars-and-labs/).

Assigned was previously called CSE+, and Pooled was previously called the Pool or case-based motion. "First Order" and "Onboarding" refer to the same motion.

## Where CSE fits in Customer Experience

CSE is part of GitLab's Customer Experience (CX) organisation. GitLab's One CX model places customer value at the
centre and groups the customer-facing motions into four areas that work together rather than competing:

- **Customer Success (CSM and CSA):** proactive adoption, consumption and risk mitigation for customers on paid Success
  Tiers.
- **Scale (CSE and Digital Success):** technical, just-in-time adoption, consumption and risk mitigation at scale. This is the CSE team, plus free
  self-serve enablement for all customers.
- **Professional Services and Education:** paid, hands-on delivery such as migrations, implementations and
  instructor-led training.
- **Renewals:** retention and the contract lifecycle, owned by the RM.

## Working with the account team

The DCI matrix below shows who is the Directly Responsible Individual (DRI), who contributes (C), and who is kept
informed (I) at each stage of the customer journey. It applies only to accounts covered by a CSE. For accounts with a
CSM or CSA, see the [CSM and CSA rules of engagement](/handbook/customer-experience/account-team/#customer-success-manager-csm).

### Pre-sales and alignment

| Activity | Task | CSE | AE | RM | SA | PS | Support | Executive Sponsor | Product and Engineering |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Identify technical champions | Define and engage key user personas for solution tailoring | I | C, I | | DRI | | | | |
| Sales to Customer Success handoff | Transfer detailed context from sales to post-sale | I | C, I | | DRI | | | | |

### Onboard

| Activity | Task | CSE | AE | RM | SA | PS | Support | Executive Sponsor | Product and Engineering |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Welcome new customers | Confirm the technical champion and send the onboarding welcome at close | I | DRI | | | | | | |
| Onboarding kickoff and first-year check-ins | Run the kickoff and the scheduled check-ins for eligible new customers | DRI | C, I | I | C | | | | |
| Technical integration and setup | Hands-on help setting up GitLab, such as architecture and deployment | | C, I | I | C, I | DRI | | | |

For Onboarding customers, the Account Manager (AM) works alongside the AE on the welcome and the kickoff.

### Enable

| Activity | Task | CSE | AE | RM | SA | PS | Support | Executive Sponsor | Product and Engineering |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| One-to-one engagement requested by the account team | A topic-scoped engagement, with the topic defined by the AE or RM before the meeting | DRI | C | I | | | | | |
| Webinars and labs | Sessions for many customers on key product topics | DRI | | I | | | | | |
| Break/fix | A bug, or the product not behaving as expected. In specific situations, Support Engineering may inform the CSE about the support ticket | (C, I) | | | | | DRI | | |
| Measure primary use case adoption | Track adoption of the primary use cases behind a request | DRI | I | I | I | | | | |

(C, I): depends on the situation.

### Expand

| Activity | Task | CSE | AE | RM | SA | PS | Support | Executive Sponsor | Product and Engineering |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Expansion discovery | Identify and pursue upsell and cross-sell opportunities | (C) | DRI | I | C | | | (I) | |
| Technical health assessment (Assigned accounts) | A recurring, internal view of adoption, technical risk and next steps | DRI | I | C, I | C | | | | |
| Account health checkups (other accounts) | Regular assessments of account health | (C) | DRI | C, I | C | | | | |

(C): depends on the situation.

### Optimize and renew

| Activity | Task | CSE | AE | RM | SA | PS | Support | Executive Sponsor | Product and Engineering |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Business review | Review successes, challenges and plans | C | DRI | I | C | | | C, I | |
| Renewal discussions | Start renewal conversations early, using what the account team knows | C, I | C | DRI | C | | | I | |
| Customer satisfaction | Capture and act on customer feedback | I | DRI | C, I | C, I | (C) | | I | I |
| Product collaboration | Capture customer needs as feature requests for Product | C, I | C | I | DRI | | | I | C, I |
| Ongoing risk review | Flag contraction or churn risk early and keep the status current | C, I | DRI | C, I | C | | | C, I | |
| Account escalation management | Trigger and lead the escalation process (account escalation or STAR) where needed | C, I | DRI | C, I | C | | C, I | C, I | I |
| Technical escalations (Assigned accounts) | Lead technical escalation handling end to end | DRI | C | C, I | C | | C, I | | |

For Assigned accounts, the assigned CSE leads technical escalations. See
[Assigned roles and responsibilities](/handbook/customer-experience/csm/segment/cse/cse-assigned/roles-responsibilities/).

## Pages in this section

- [Assigned](/handbook/customer-experience/csm/segment/cse/cse-assigned/) and its
  [roles and responsibilities](/handbook/customer-experience/csm/segment/cse/cse-assigned/roles-responsibilities/)
- [Pooled](/handbook/customer-experience/csm/segment/cse/pooled/) and its
  [offerings](/handbook/customer-experience/csm/segment/cse/pooled/offerings/)
- [Onboarding (First Order)](/handbook/customer-experience/csm/segment/cse/customer-onboarding/)
- [How CSEs run customer engagements](/handbook/customer-experience/csm/segment/cse/customer-engagements/)
- [Webinars and hands-on labs](/handbook/customer-experience/csm/segment/cse/webinars-and-labs/)
- [A day in the life of a CSE](/handbook/customer-experience/csm/segment/cse/day-in-the-life/)
- [CSE team member onboarding](/handbook/customer-experience/csm/segment/cse/team-member-onboarding/)
- [CSE job family](/job-description-library/sales/customer-success-engineer/)

Page under review, set for enhancement:

- [CSM to CSE handover](/handbook/customer-experience/csm/segment/cse/csm-to-cse-handover/)
