---
title: "CSE Assigned: Health Assessments & CTAs"
description: "How to run health assessments and use CTAs to track follow-up work for CSE Assigned accounts."
weight: 40
---

## Health assessments

- **Cadence:** one per account per rolling 90 days.
- **Mandatory sections:** a short TL;DR, then an executive overview covering account basics (product/tier/seats/renewal date), usage summary, support, customer interactions, risk assessment, and proposed next steps.
- An assessment looks at adoption across the main use cases (SCM, CI, CD and security), license utilisation, adoption of GitLab Duo and the Duo Agent Platform, support history, recent engagement, and, for self-managed instances, how current the GitLab version is.
- Health assessments are **internal-facing only**, they are not customer-facing. Running an assessment does not by itself mean the customer will be contacted; the CSE reaches out when there is a reason to.
- The output is logged in our customer success platform for the account team. It is not automatically a CTA.
- **Method:** an automated data pull, reviewed and augmented with the CSE's own account knowledge gained from customer interactions and AE/RM catch-ups. The TL;DR and executive summary are shared with the account team.
- **If usage data isn't available:** the CSE may ask the customer directly, and uses engagement frequency, interactions, and support tickets as signal in the meantime.

## CTAs

- CTAs are **not a performance metric**. They exist to structure work and give portfolio visibility.
- A CTA is only opened when a health assessment surfaces follow-up work, or a customer requests guidance on a specific topic. A healthy account with no follow-up needs no CTA.
- Adoption follow-ups: if the follow-up includes a series of several light questions, the recommendation is to do one general CTA, however if the topics are wider and more complex, and require more work, create one CTA per topic. Close with documented outcomes (topics covered, recommendations with links, customer's next actions).
- Escalations follow the [CSM escalation process](/handbook/customer-experience/csm/escalations/):
  1. Risk surfaces: health assessment or signal identifies an issue.
  2. Immediate flag: notify AE/RM and CSE manager; don't wait.
  3. Track the escalation following the CSM escalation process.
  4. End-to-end ownership: the assigned CSE manages through resolution, with the account team in the loop throughout.
- Customer-introduction CTAs are recommended, not mandatory.
