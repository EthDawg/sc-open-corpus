---
title: "CSE Pooled: Offerings"
description: "The CSE offerings the account team can request in the Pooled motion, with what is in and out of scope for each."
weight: 20
---

These are the offerings the account team can choose from when they request a Customer Success Engineer (CSE) in the
[Pooled motion](/handbook/customer-experience/csm/segment/cse/pooled/).

CSE sessions are advisory. CSEs share guidance, recommendations and best practices; they do not make hands-on changes
in the customer's environment. The offering chosen does not need to be an exact match: it helps the CSE prepare and
helps us track what customers ask for.

## CI/CD and DevOps

### Streamline your CI workflows

Engineering leads and DevOps teams learn how to improve CI pipeline performance and resource use. The CSE reviews the
customer's `.gitlab-ci.yml` configuration and shares patterns for job efficiency, caching and pipeline architecture.

| In scope | Out of scope |
| --- | --- |
| Review of the current CI pipeline configuration | Direct pipeline changes |
| Runner guidance and best practices | |
| Optimisation patterns | Runner setup or configuration |
| Caching recommendations | Debugging specific pipeline failures |
| Job efficiency improvements | Writing custom pipeline code |
| Pipeline architecture best practices | |

Resources:

- **Documentation:** [GitLab CI/CD](https://docs.gitlab.com/ci/), [Use CI/CD to build your application](https://docs.gitlab.com/topics/build_your_application/), [Pipeline efficiency](https://docs.gitlab.com/ci/pipelines/pipeline_efficiency/), [Pipeline architectures](https://docs.gitlab.com/ci/pipelines/pipeline_architectures/), [CI/CD YAML reference](https://docs.gitlab.com/ci/yaml/), [GitLab Runner configuration](https://docs.gitlab.com/runner/configuration/), [CI/CD Catalog](https://docs.gitlab.com/ci/components/#cicd-catalog), [CI/CD components](https://docs.gitlab.com/ci/components/)
- **Blog posts:** [Extract greater efficiency from your CI pipelines](https://about.gitlab.com/blog/2022/03/09/efficient-pipelines/), [3 YAML tips for better pipelines](https://about.gitlab.com/blog/2020/10/01/three-yaml-tips-better-pipelines/), [Introducing the GitLab CI/CD Catalog Beta](https://about.gitlab.com/blog/2023/12/21/introducing-the-gitlab-ci-cd-catalog-beta/), [Introducing CI/CD components](https://about.gitlab.com/blog/2023/07/10/introducing-ci-components/), [How to build more reusable CI/CD templates](https://about.gitlab.com/blog/2023/05/01/how-to-build-reusable-ci-templates/), [Define input parameters to includable CI/CD configuration files](https://about.gitlab.com/blog/2023/05/08/use-inputs-in-includable-files/), [How to automate the creation of GitLab Runners](https://about.gitlab.com/blog/2023/07/06/how-to-automate-creation-of-runners/), [3 GitLab features to level up DevSecOps workflows](https://about.gitlab.com/blog/2024/10/29/3-gitlab-features-to-level-up-devsecops-workflows/)
- **Related webinars/labs:** Intro to GitLab, Intro to CI/CD with GitLab, Advanced CI/CD, GitLab Runners Overview, CI/CD Components, Lab: Intro to CI, Lab: Advanced CI/CD

### Accelerate your software delivery

DevOps teams learn how to make continuous deployment more reliable: deployment automation, environment configuration
and release management.

| In scope | Out of scope |
| --- | --- |
| Deployment automation strategy | Environment setup |
| Environment configuration recommendations | Custom deployment scripts |
| Release management | Direct infrastructure configuration |
| Improving reliability and deployment frequency | Running deployments |

Resources:

- **Documentation:** [Deploy and release your application](https://docs.gitlab.com/topics/release_your_application/), [Getting started with deploy and release](https://docs.gitlab.com/user/get_started/get_started_deploy_release/), [Packages and registries](https://docs.gitlab.com/user/packages/), [Environments](https://docs.gitlab.com/ci/environments/), [Deployments](https://docs.gitlab.com/ci/environments/deployments/), [Releases](https://docs.gitlab.com/user/project/releases/), [Incremental rollouts](https://docs.gitlab.com/ci/environments/incremental_rollouts/), [Feature flags](https://docs.gitlab.com/operations/feature_flags/)
- **Blog posts:** [CI, delivery, and deployment with GitLab](https://about.gitlab.com/blog/2016/08/05/continuous-integration-delivery-and-deployment-with-gitlab/), [CI deployment and environments](https://about.gitlab.com/blog/2021/02/05/ci-deployment-and-environments/), [From code to production: a guide to continuous deployment with GitLab](https://about.gitlab.com/blog/2025/01/28/from-code-to-production-a-guide-to-continuous-deployment-with-gitlab/), [Safe deploys](https://about.gitlab.com/blog/2020/07/23/safe-deploys/)
- **Related webinar:** [Advanced CI/CD](https://www.youtube.com/watch?v=N7YIRQrNe50)

## Security and compliance

### Strengthen your application security

Development and security leads learn how to automate security scanning, enforce security policies and manage
vulnerabilities without slowing development down.

| In scope | Out of scope |
| --- | --- |
| Security scanning strategy | Custom security rule development |
| Policy enforcement recommendations | Fixing specific vulnerabilities |
| Vulnerability management workflow | Hands-on integration of external security tools |
| Security feature configuration guidance | Writing compliance documentation |
| Integrating security into CI/CD pipelines | |
| Finding and walking through the relevant documentation, and spotting product or documentation gaps | |

Resources:

- **Documentation:** [Get started securing your application](https://docs.gitlab.com/user/application_security/get-started-security/), [Application security testing](https://docs.gitlab.com/user/application_security/). Scanners: [Secret detection](https://docs.gitlab.com/user/application_security/secret_detection/), [Dependency scanning](https://docs.gitlab.com/user/application_security/dependency_scanning/), [SAST](https://docs.gitlab.com/user/application_security/sast/), [DAST](https://docs.gitlab.com/user/application_security/dast/), [Coverage-guided fuzz testing](https://docs.gitlab.com/user/application_security/coverage_fuzzing/), [Web API fuzzing](https://docs.gitlab.com/user/application_security/api_fuzzing/), [Container scanning](https://docs.gitlab.com/user/application_security/container_scanning/) (video overview: https://www.youtube.com/watch?v=C0jn2eN5MAs, walkthrough: https://youtu.be/h__mcXpil_4, tutorial: [Scan a Docker container for vulnerabilities](https://docs.gitlab.com/tutorials/container_scanning/)). Handling results: [Merge request approvals](https://docs.gitlab.com/user/project/merge_requests/approvals/), [Approval rules](https://docs.gitlab.com/user/project/merge_requests/approvals/rules/), [Vulnerability report](https://docs.gitlab.com/user/application_security/vulnerability_report/) (Ultimate). [Policies](https://docs.gitlab.com/user/application_security/policies/) (Ultimate): [Scan execution](https://docs.gitlab.com/user/application_security/policies/scan_execution_policies/), [Merge request approval](https://docs.gitlab.com/user/application_security/policies/merge_request_approval_policies/), [Pipeline execution](https://docs.gitlab.com/user/application_security/policies/pipeline_execution_policies/), [Vulnerability management](https://docs.gitlab.com/user/application_security/policies/vulnerability_management_policy/)
- **Blog posts:** [Getting started with GitLab application security](https://about.gitlab.com/blog/2023/03/15/getting-started-with-gitlab-application-security/), [How to action security vulnerabilities in GitLab Premium](https://about.gitlab.com/blog/2023/03/13/actioning-security-vulnerabilities-in-gitlab-premium/), [Security and governance updates in GitLab 17, 17.1](https://about.gitlab.com/blog/2024/07/17/get-to-know-the-security-and-governance-updates-in-gitlab-17-17-1/), [Migration guide: GitHub Advanced Security to GitLab Ultimate](https://about.gitlab.com/blog/2024/05/01/migration-guide-github-advanced-security-to-gitlab-ultimate/), [How to integrate custom security scanners into GitLab](https://about.gitlab.com/blog/2024/02/27/how-to-integrate-custom-security-scanners-into-gitlab/), [Quick vulnerability remediation with GitLab Advanced SAST + Duo AI](https://about.gitlab.com/blog/2024/10/22/quick-vulnerability-remediation-with-gitlab-advanced-sast-duo-ai/)
- **Other resources:** [GitLab University: Security](https://university.gitlab.com/pages/security-content), [SAST rules](https://gitlab.com/gitlab-org/security-products/sast-rules), [Security scanning demo project](https://gitlab.com/gitlab-da/tutorials/security-and-governance/devsecops/simply-vulnerable-notes)
- **Related webinars/labs:** Security and Compliance Lab, Holistic Approach to Securing the Development Lifecycle

## AI: GitLab Duo and the Duo Agent Platform

### Transform your workflow with AI

Development teams and technical leaders learn how to use GitLab Duo and the Duo Agent Platform across the software
development workflow: planning, coding, review and security.

| In scope | Out of scope |
| --- | --- |
| GitLab Duo and Duo Agent Platform feature overviews and implementation strategies | Custom AI model configuration |
| Use-case discovery for GitLab Duo and the Duo Agent Platform | |
| Planning workflow enhancement strategies | |
| Adoption and implementation strategies | Building specific review automation |
| AI-assisted code review and security recommendations | Implementing features on the customer's behalf |
| Getting the most from Code Suggestions | Reviewing individual code suggestions |
| Finding and walking through the relevant documentation, and spotting product or documentation gaps | |

Resources:

- **Documentation:** [GitLab Duo](https://docs.gitlab.com/user/gitlab_duo/), [Code Suggestions](https://docs.gitlab.com/user/project/repository/code_suggestions/)
- **Blog posts:** [GitLab blog: AI/ML](https://about.gitlab.com/blog/categories/ai-ml/), [Refactor code into modern languages with GitLab Duo](https://about.gitlab.com/blog/2024/08/26/refactor-code-into-modern-languages-with-ai-powered-gitlab-duo/), [Top tips for efficient Code Suggestions](https://about.gitlab.com/blog/2024/06/11/top-tips-for-efficient-ai-powered-code-suggestions-with-gitlab-duo/), [10 best practices for GitLab Duo Chat](https://about.gitlab.com/blog/2024/04/02/10-best-practices-for-using-ai-powered-gitlab-duo-chat/)
- **Other resources:** [GitLab University: GitLab Duo](https://university.gitlab.com/pages/ai); click-through demos: [Duo Chat](https://tech-marketing.gitlab.io/static-demos/duo-chat.html), [GitLab Duo](https://tech-marketing.gitlab.io/static-demos/ai-demos.html), [Resolving vulnerabilities with GitLab Duo](https://tech-marketing.gitlab.io/static-demos/pt-explain-vulnerability.html); product tours: [Duo Self-Hosted](https://gitlab.navattic.com/gitlab-duo-self-hosted), [Duo with Amazon Q](https://gitlab.navattic.com/duo-q), [AI impact analytics](https://gitlab.navattic.com/ai-impact), [Duo Enterprise](https://gitlab.navattic.com/duo-enterprise), [Code Suggestions](https://gitlab.navattic.com/code-suggestions); YouTube: [GitLab Duo Snapshots](https://www.youtube.com/playlist?list=PLFGfElNsQthZGazU1ZdfDpegu0HflunXW), [DevOps with GitLab Duo](https://www.youtube.com/playlist?list=PL05JrBw4t0Krzu4U6gO3tS738hlsQGFz5), [GitLab Duo Coffee Chat](/handbook/marketing/product-and-technical-marketing/developer-advocacy/projects/#gitlab-duo-coffee-chat)

## Migration and architecture

### Optimize your migration strategy

Technical leaders and migration teams learn how to move to GitLab with minimal disruption: migration approaches,
prerequisites and limitations, architecture considerations and risk mitigation, whether they are moving from another
tool, from self-managed to GitLab.com, or between GitLab instances.

| In scope | Out of scope |
| --- | --- |
| Migration approach planning | Running the migration |
| Risk mitigation | Custom scripts |
| Architecture considerations | Data clean-up |
| Phased transition planning | Direct implementation work |
| Timeline and resource planning guidance | |

Resources:

- **Documentation:** [Import and migrate groups and projects](https://docs.gitlab.com/user/project/import/), [Plan a migration to GitLab CI/CD](https://docs.gitlab.com/ci/migration/plan_a_migration/), migrating from [Bamboo](https://docs.gitlab.com/ci/migration/bamboo/), [CircleCI](https://docs.gitlab.com/ci/migration/circleci/), [GitHub Actions](https://docs.gitlab.com/ci/migration/github_actions/), [Jenkins](https://docs.gitlab.com/ci/migration/jenkins/), [TeamCity](https://docs.gitlab.com/ci/migration/teamcity/); [Direct transfer](https://docs.gitlab.com/user/group/import/), [File exports](https://docs.gitlab.com/user/project/settings/import_export/), import from [GitHub](https://docs.gitlab.com/user/project/import/github/), [Bitbucket Cloud](https://docs.gitlab.com/user/project/import/bitbucket/), [Bitbucket Server](https://docs.gitlab.com/user/project/import/bitbucket_server/); [Migrate to a new server](https://docs.gitlab.com/administration/backup_restore/migrate_to_new_server/), [Jira migration options](https://docs.gitlab.com/user/project/import/jira_migration_options/)
- **Blog posts:** [Jenkins-to-GitLab migration made easy](https://about.gitlab.com/blog/2024/02/01/jenkins-to-gitlab-migration-made-easy/), [GitHub to GitLab migration the easy way](https://about.gitlab.com/blog/2023/07/11/github-to-gitlab-migration-made-easy/), [GitLab project migration and automation](https://about.gitlab.com/blog/2023/01/18/try-out-new-way-to-migrate-projects/), [Migrate from Jira to GitLab with Jira2Lab at scale](https://about.gitlab.com/blog/2024/10/10/seamlessly-migrate-from-jira-to-gitlab-with-jira2lab-at-scale/), [How to migrate GitLab groups and projects more efficiently](https://about.gitlab.com/blog/2023/08/02/how-to-migrate-gitlab-groups-and-projects-more-efficiently/), [Tips for a successful Jira to GitLab migration](https://about.gitlab.com/blog/2023/10/24/tips-for-a-successful-jira-to-gitlab-migration/)
- **Other resources:** [GitLab University: Migrating to GitLab](https://university.gitlab.com/pages/migrating-to-gitlab), webinar [Preparing a GitLab migration from self-managed to SaaS](https://www.youtube.com/watch?v=zuDu5sL_p-g)

### Optimize your GitLab architecture

Enterprise architects and technical leads learn how to design a robust, scalable GitLab deployment, including high
availability and disaster recovery.

| In scope | Out of scope |
| --- | --- |
| Architecture patterns and recommendations | Infrastructure setup or changes |
| High availability guidance | Hands-on configuration |
| Disaster recovery and Geo strategy | Choosing specific hardware or cloud providers |
| Scalability planning | Implementing high availability or Geo |
| Backup strategy | Backup solutions outside the official documentation |

Resources:

- **Documentation:** [Architecture overview](https://docs.gitlab.com/development/architecture/), [Reference architectures](https://docs.gitlab.com/administration/reference_architectures/), [GitLab Geo](https://docs.gitlab.com/administration/geo/), [GitLab scalability (components)](https://docs.gitlab.com/development/scalability/)
- **Other resources:** [GitLab Environment Toolkit](https://gitlab.com/gitlab-org/gitlab-environment-toolkit), [GET Deployment Workshop](https://gitlab.com/gitlab-org/professional-services-automation/tools/implementation/get-deployment-workshop), [GitLab Certified Implementation Services Specialist learning path](https://university.gitlab.com/learning-paths/gitlab-certified-implementation-services-specialist-learning-path)

## Platform and operations

### Fast-track GitLab implementation

DevOps leads and platform administrators get concrete recommendations for an initial GitLab rollout: configuration,
user management, rollout sequence and documented best practices.

| In scope | Out of scope |
| --- | --- |
| Configuration best practices | Hands-on configuration changes |
| User management strategy | Custom scripts and integrations |
| Rollout planning and sequencing | Setting up and managing users |
| New releases, deprecations and instance upgrades | Direct implementation work |

Resources:

- **Documentation:** [GitLab administration](https://docs.gitlab.com/administration/), [User and group management](https://docs.gitlab.com/administration/auth/), [Installation guide](https://docs.gitlab.com/install/), [Upgrading GitLab](https://docs.gitlab.com/update/), [Subgroups](https://docs.gitlab.com/user/group/subgroups/), [User account](https://docs.gitlab.com/user/profile/), [Organization](https://docs.gitlab.com/user/organization/)
- **Blog posts:** [Getting started with GitLab: How to manage users](https://about.gitlab.com/blog/2025/01/14/getting-started-with-gitlab-how-to-manage-users/), [The ultimate guide to least privilege access with GitLab](https://about.gitlab.com/blog/2024/03/06/the-ultimate-guide-to-least-privilege-access-with-gitlab/), [How to automate the creation of GitLab Runners](https://about.gitlab.com/blog/2023/07/06/how-to-automate-creation-of-runners/)
- **Related webinars/labs:** GitLab User Admin 101, GitLab Administration on GitLab.com, Git Basics, Intro to GitLab, GitLab Runners Overview, Separation of Duties, Continuous Change, Lab: GitLab Fundamentals

### Strengthen your GitLab operations

System administrators learn how to run GitLab at scale: authentication, user management, group structure and project
configuration.

| In scope | Out of scope |
| --- | --- |
| Authentication strategy | Direct configuration changes |
| User management | User directory integration |
| Group structure | Custom scripts |
| Project configuration | Implementation work |
| Administration best practices | |

Resources:

- **Documentation:** [Manage your organization](https://docs.gitlab.com/topics/set_up_organization/), [Tutorial: set up your organization](https://docs.gitlab.com/tutorials/manage_user/), [Namespaces](https://docs.gitlab.com/user/namespace/), [Members](https://docs.gitlab.com/user/project/members/), [Organization](https://docs.gitlab.com/user/organization/), [Groups](https://docs.gitlab.com/user/group/), [Sharing projects and groups](https://docs.gitlab.com/user/project/members/sharing_projects_groups/), [Enterprise users](https://docs.gitlab.com/user/enterprise_user/), [Service accounts](https://docs.gitlab.com/user/profile/service_accounts/), [User account](https://docs.gitlab.com/user/profile/), [SSH keys](https://docs.gitlab.com/user/ssh/), [GitLab.com settings](https://docs.gitlab.com/user/gitlab_com/), [Organize work with projects](https://docs.gitlab.com/user/project/organize_work_with_projects/), [Get started with projects](https://docs.gitlab.com/user/get_started/get_started_projects/), [Create a project](https://docs.gitlab.com/user/project/), [Manage projects](https://docs.gitlab.com/user/project/working_with_projects/), [Project visibility](https://docs.gitlab.com/user/public_access/), [Project settings](https://docs.gitlab.com/user/project/settings/), [Description templates](https://docs.gitlab.com/user/project/description_templates/), [Project access tokens](https://docs.gitlab.com/user/project/settings/project_access_tokens/), [Deploy keys](https://docs.gitlab.com/user/project/deploy_keys/), [Deploy tokens](https://docs.gitlab.com/user/project/deploy_tokens/), [Reserved names](https://docs.gitlab.com/user/reserved_names/), [Search](https://docs.gitlab.com/user/search/), [Badges](https://docs.gitlab.com/user/project/badges/), [Project topics](https://docs.gitlab.com/user/project/project_topics/)
- **Related webinar:** GitLab Administration on GitLab.com

### Optimize your platform observability

Platform engineers learn how to monitor GitLab: from basic system monitoring to observability, housekeeping and
resource tracking.

| In scope | Out of scope |
| --- | --- |
| Monitoring strategy | Setting up monitoring tools |
| Observability guidance | Configuring alerts |
| Resource tracking | Building custom dashboards |
| Performance metrics | Troubleshooting specific issues |
| Housekeeping and garbage collection | |

Resources:

- **Documentation:** [Monitoring GitLab](https://docs.gitlab.com/administration/monitoring/), [Performance monitoring](https://docs.gitlab.com/administration/monitoring/performance/), [Logs](https://docs.gitlab.com/administration/logs/), [Audit event streaming](https://docs.gitlab.com/administration/compliance/audit_event_streaming/), [Container registry administration](https://docs.gitlab.com/administration/packages/container_registry/), [Reduce package registry storage](https://docs.gitlab.com/user/packages/package_registry/reduce_package_registry_storage/), [Housekeeping](https://docs.gitlab.com/administration/housekeeping/), [Performance bar](https://docs.gitlab.com/administration/monitoring/performance/performance_bar/)
- **Other resources:** [GitLab Performance Tool (GPT) quick start](/handbook/support/workflows/gpt_quick_start/)

### Scale your agile planning

Project leaders and delivery teams learn how to plan with issues, epics and iterations, track dependencies, and
measure progress with value stream analytics.

| In scope | Out of scope |
| --- | --- |
| Planning workflow strategy | Setting up the workflow |
| Issue and epic management | Custom field configuration |
| Iteration planning | Creating templates |
| Dependency tracking | Team training sessions |
| Value stream analytics review | |

Resources:

- **Documentation:** [Plan and track work](https://docs.gitlab.com/topics/plan_and_track/), [Value stream analytics](https://docs.gitlab.com/user/group/value_stream_analytics/), [Epics](https://docs.gitlab.com/user/group/epics/), [Iterations](https://docs.gitlab.com/user/group/iterations/)
- **Related webinars:** Getting Started with DevOps Metrics, Jira to GitLab

## When a customer needs more

- **Hands-on delivery** such as running a migration, building integrations, or deploying an architecture is a
  [Professional Services](https://about.gitlab.com/services/) engagement. The guidance and design advice in the
  offerings above stay with the CSE.
- **Ongoing guidance** such as a regular call cadence, help with a roadmap, custom workshops or follow-up on feature
  requests is part of the [Success Tiers](/handbook/customer-experience/success-services/).

The CSE flags either need to the account team.
