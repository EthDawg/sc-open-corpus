---
title: "CSE Webinars and Hands-on Labs"
description: "The CSE team's monthly programme of customer webinars and hands-on labs, how sessions are delivered, and presenter guidance for CSEs."
weight: 40
---

The Customer Success Engineering (CSE) team runs a monthly programme of webinars and hands-on labs that is open to
everyone. It is one of the main ways the team delivers value at scale: one
well-run session reaches dozens or hundreds of customers at once.

## For customers

- **Webinars** are pre-recorded sessions on a GitLab topic, with CSEs answering questions live in the Q&A panel.
- **Hands-on labs** give each attendee their own lab environment for a few days, so they can work through the
  exercises during the session and afterwards.

The calendar, with a registration link for each session, is on the
[GitLab University webinar page](https://university.gitlab.com/pages/gitlab-user-webinars). Recordings of past
webinars are on the [GitLab webinars YouTube playlist](https://www.youtube.com/playlist?list=PL05JrBw4t0Kpczt4pRtyF147Uvn2bGGvq),
and lab content lives in the public [GitLab Learn Labs sample projects](https://gitlab.com/gitlab-learn-labs/sample-projects).

For labs, you need a GitLab.com account before you start. In both webinars and labs, attendees are muted and ask
their questions in the Q&A panel.

## How the programme runs

Each session has a DRI, usually a CSE who signed up to present, who owns the preparation and delivery. A co-pilot
works the chat and Q&A alongside them. A programme manager handles the communication with attendees before and after
each session, including the follow-up email with the recording and slides.

New CSEs join first as co-pilots and move on to presenting as they ramp. See
[CSE team member onboarding](/handbook/customer-experience/csm/segment/cse/team-member-onboarding/#webinars).

## The co-pilot role

The co-pilot is not just a backup presenter. In a live session with an active Q&A queue, they are working the whole time.

**Before the session**

- Review the deck and content so you can answer basic questions in the chat without pulling in the presenter.
- Get the paste notes from the DRI, or build them together: a running document of every link, command and resource
  to share at the right moment.
- Log in at least 10 minutes before the start.

**During the session**

- Watch both the Q&A panel and the chat. They are not the same.
- Answer in the chat where you are confident. Save anything complex or sensitive for the presenter at a natural
  break.
- Share links when they become relevant, not all at once at the start.
- Track questions you cannot answer live, for the follow-up email.
- Keep an eye on the clock and signal the presenter if they are running long.

**After the session**

- Contribute to the follow-up email if asked, and flag any questions left unanswered so they are covered in it.

## Preparing to present

- **Run through the content end to end at least once**, especially for labs. A step that fails in front of 60
  attendees makes for a painful few minutes. Time the run-through and aim for 80% of the slot: nerves make most
  presenters run long.
- **Build your paste notes in advance**, and share them with anyone helping with Q&A.
- **Check the lab environment** well before the session, including the access codes attendees will use.
- **Set up for live delivery:** two windows side by side (slides full screen, and the lab or demo environment), all
  notifications off, the bookmarks bar hidden, and nothing on screen that relates to other customers. Join at least
  10 minutes early, and confirm the recording is running and attendees have been informed.
- **Go slower than you think you need to** through lab exercises.

### When a question stumps you

Every presenter gets a question they cannot answer live. The answer is always the same: "Good question. Let me make
sure I give you the right answer, and I'll follow up after the session." Write it down and follow up. One accurate
follow-up builds more credibility than five confident answers that turn out to be wrong.

If a question reveals a product gap or a documentation issue, raise it with the relevant
[product group](/handbook/product/categories/features/) after the session.

## Related pages

- [CSE homepage](/handbook/customer-experience/csm/segment/cse/)
- [A day in the life of a CSE](/handbook/customer-experience/csm/segment/cse/day-in-the-life/)
