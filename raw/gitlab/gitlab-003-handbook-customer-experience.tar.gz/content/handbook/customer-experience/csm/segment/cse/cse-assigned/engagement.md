---
title: "CSE Assigned: Engagement & CSE vs. Success Tiers"
description: "How CSEs engage customers directly, and how CSE Assigned compares to Pooled and Success Tiers."
weight: 50
---

Customer interactions and motion differentiation.

## Customer engagement

CSEs engage customers directly when their work requires it, to validate signals, gather context not available in product data, or advance a risk or enablement action, with the account team kept in the loop. The CSE's health assessment adds to what the account team already knows.

After the AE or RM introduces the CSE, the customer works with the CSE directly. The assigned CSE is the account's post-sales technical resource, so the customer can reach out whenever they need help with anything in the scope of CSE Assigned, without going through the account team. The AE remains the customer’s primary contact for the overall relationship.

An **engagement** is a bounded, topic-scoped body of work with a customer, for example answering a technical question, working through an adoption topic, or resolving a technical issue (but not a break/fix situation, this is for the support team). It typically takes 1-3 interactions (calls, emails, or working sessions), not an ongoing relationship. This is distinct from the mandatory quarterly customer touch: a touch keeps the account warm, an engagement is a discrete piece of work. As a guide, an Assigned account has up to **three engagements per quarter**. The guide is not a hard cap: being proactive means that when a customer needs help, we help. The limits in the RACI and the comparison tables are a signal, not a gate. When an account needs far more help than most, such as near-daily support, it is a sign the customer may be better served by a Success Tier, and the CSE raises it with the account team ahead of the renewal.

CSEs should not join persistent Slack channels that include customers. Engagements are bounded and topic-scoped by design. A standing customer Slack channel creates an unbounded, always-on relationship that works against that model and blurs the line with Success Tiers coverage. Use email or scheduled calls instead.

> **When a customer is not available to engage:** the health assessment still proceeds using available data (usage signals, account history, AE/SA context), and the CSE stays available.

## CSE Assigned vs. Success Tiers

CSE Assigned and Success Tiers are complementary, not competing. CSE Assigned is a risk-focused, quarterly motion included in the customer's contract. Success Tiers are a paid, high-touch offering. When a customer requests more depth than CSE Assigned delivers, that is a Success Tiers opportunity for the AE, not a scope expansion for the CSE.

| | Pooled (CSE) | CSE Assigned | Success Tiers (Essentials / Advanced / Signature) |
|---|---|---|---|
| **Engagement model** | Reactive, case-based | Proactive, quarterly | Proactive, ongoing |
| **Named resource** | - | ✔ | ✔ |
| **Cadence** | On demand | Quarterly | Monthly or more |
| **Engagement limit** | 3 cases max per account per half year | 3 engagements per account per quarter (guide) | Uncapped (per standard cadence) |
| **Health monitoring** | - | ✔ | ✔ |
| **Escalation management** | - | ✔ | ✔ |
| **Success planning** | - | - | ✔ |
| **EBR / QBR** | - | - | ✔ |
| **Workshops** | Public schedule only | Public schedule only | Tailored |
| **Cost to customer** | Included | Included | Paid |
