---
title: CSE Assigned
weight: 1
description: >
    Overview of the CSE Assigned motion: proactive, named-CSE coverage for qualifying accounts without a CSM or CSA.
---

View the [CSE Handbook homepage](/handbook/customer-experience/csm/segment/cse/) for additional CSE-related handbook pages.

---

Customer Success Engineering · Proactive Motion

CSE Assigned is a proactive motion in which a named Customer Success Engineer owns recurring health assessments and risk management for a defined book of accounts. It is one of three CSE motions, designed so that every qualifying account without a named CSM/CSA has a dedicated technical owner who spots adoption blockers and technical issues early, without requiring a case to be opened.

Each CSE owns a defined book of accounts, conducting recurring health assessments that evaluate product adoption, technical risk, and customer health. The CSE works as a technical extension of the account team, closely aligned with the account's Renewals Manager and Account Executive, surfacing risk signals, managing escalations, and flagging growth opportunities, without requiring a case or ticket from the customer.

This motion sits between the **[Pooled](/handbook/customer-experience/csm/segment/cse/pooled/)** motion (reactive, case-based coverage) and **[Success Tiers](/handbook/customer-experience/success-services/)** (paid, high-touch engagements). CSE Assigned is included in the customer's contract at no additional cost. It is not a replacement for Success Tiers. When a customer requests deeper engagement, that's a Success Tiers opportunity for the AE.

> **Eligibility:** CSE Assigned covers qualifying accounts without a CSM or CSA. For eligibility threshold, consult the internal handbook. The practical limit is capacity: each CSE carries a defined book of accounts, so coverage is bounded by book size.

## On this page

1. [Who Is Covered & Scope of the Role](scope/)
1. [Roles and Responsibilities](roles-responsibilities/)
1. [Health Assessments & CTAs](assessments-ctas/)
1. [Engagement & CSE vs. Success Tiers](engagement/)
