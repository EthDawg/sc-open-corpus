---
title: "CSE Assigned: Who Is Covered & Scope of the Role"
description: "Who is covered by CSE Assigned, and what is and isn't in scope for the role, including escalation ownership."
weight: 10
---

## Who is covered

CSE Assigned covers qualifying accounts that do not have a CSM or CSA. Each CSE carries a defined book of accounts, aligned to RM/RD territory; coverage is bounded by that capacity.

## Scope of the role

CSE Assigned owns the technical health layer of an account. It does not replace the account team's relationship function or the depth of engagement available through paid Success Tiers.

| CSE Assigned does | CSE Assigned does not |
|---|---|
| Run recurring health assessments on adoption signals and technical risk | Run EBRs or QBRs |
| Own end-to-end escalation management for assigned accounts, as the escalation DRI | Deliver Success Plans or Success Tier engagements |
| Partner with the account team (AE, RM, SA) and engage customers directly when work requires it | Act as a relationship manager or CSM substitute |
| Recognise when a customer needs more help than CSE Assigned provides (Professional Services or a Success Tier) and connect them with the account team | Provide unlimited, ongoing engagement: around three engagements per account per quarter is the guide (see [Engagement & CSE vs. Success Tiers](/handbook/customer-experience/csm/segment/cse/cse-assigned/engagement/)) |
| Surface product-centric risk signals that feed existing account team conversations | Fulfill a customer's request for deeper advisory. That's a Success Tiers conversation for the AE |

## Escalation ownership

For CSE Assigned accounts specifically, **the assigned CSE is the escalation DRI**. This does not change how Pooled escalations are handled: the regional CSE leader remains DRI for Pooled. See the [Customer Success Escalations Process](/handbook/customer-experience/csm/escalations/) page for the full escalation process.
