---
title: Customer Success Escalations Process
---

View the [CSM Handbook homepage](/handbook/customer-experience/csm/) for additional CSM-related handbook pages.

---

## Background

Escalations can take at least two different forms:

1. Account Escalation.  This occurs when the customer expresses or a GitLab team member identifies that a customer is facing a challenging situation that may or may not relate to a specific support ticket. Anyone in GitLab can [open an account escalation](#opening-the-escalation) and [circulate it to the leadership of the appropriate group to find a DRI](#escalation-dri).
1. Support Ticket Attention Requests (STAR).  This occurs when an open support ticket is deemed moving too slowly or needs to be raised in priority.

The purpose of this handbook entry is to describe the process for __account escalations__.  If a support case needs attention or needs to be raised in severity, please follow the STAR process rather than using account escalations. Please see the [Support Ticket Attention Requests](/handbook/support/internal-support/support-ticket-attention-requests/) for details on how to request a support ticket escalation.

Support account escalations should be focused on delays across multiple support tickets, customer satisfaction with support response in a ticket, systemic support experience concerns, or other account related issues. Please __do not__ open an account escalation to raise the priority of a Support ticket.

For a detailed walkthrough of the process, please login to GitLab Unfiltered and view this [video](https://youtu.be/-nDaRndgy4Y).

## Objective

Define the process for managing account escalations and define a framework for communications, activities, and expectations for customer escalations.

## Scope

This process addresses escalations for CS-assigned customers. This process can also apply to other segments if a strategic partnership or relationship exists. Any GitLab team member can escalate an account on behalf of the customer.

## Definitions of Severity Levels

| Severity Level | Description | Cadence | Levels of Involvement |
| -------------- | ----------- | ------- | --------------------- |
| Critical | Major issue(s) significantly impact customers' ability to deploy or use a solution, risk loss of or use of a solution, high risk loss of a customer or significant contraction, or significant risk to the relationship and brand. | Daily | VP of Sales, Product, CRO, CEO, VP of Customer Success, Global/PubSec CSM Leader |
| High | Major issue(s) significantly impact a customer's ability to deploy or use a solution, risking current adoption, risk of loss of customer or contraction, future growth on the account, and damage to the relationship. | Multiple times per week | VP of Sales, Product, CRO, CEO, VP of Customer Success, Global/PubSec CSM Leader |
| Medium | Issue(s) impact a customer's ability to deploy or use the product, risking current adoption and renewal. | Weekly to Bi-weekly | Global/PubSec CSM Leader |
| Low | Issue(s) impacting a customer's ability to deploy or use the product, risking customer value realization, timeline, customer satisfaction, and adoption levels. | Standard Communication | Regional CSM Manager, Account Manager |

- Cadence refers to the cadence of internal and external meetings and communications to the customer.
- Level of involvement defines scope of internal communication and awareness. Others can be included based on the type of issues involved.

### Escalation DRI

The DRI for the escalation is determined by evaluating these options in order:

1. If the escalation is related to an ongoing Professional Services project, the Professional Services Project Manager will be the DRI of the escalation.
1. If the escalation is NOT related to an ongoing Professional Services project and there is a CSM assigned to the account, the CSM will be the DRI.
1. If the customer does not have an assigned CSM but is assigned to TAM Scale (Customer Success Engineering), then the regional CSE leader will be DRI, with CSEs providing technical support as needed.

```mermaid
flowchart TD;
    A[Account Escalation Identified] --> B{Is this related to a Professional Services Project?};
    B -->|Yes| C[Professional Services Project Manager is DRI];
    B -->|No| D{Does customer have an assigned CSM?};
    D -->|Yes| E[CSM is DRI];
    D -->|No| F[Customer assigned to TAM Scale];
    F --> G[Regional CSE leader is DRI];
```

At the beginning of the escalation, the DRI must be determined - the DRI owns the following responsibilities and key steps:

- Overall articulation of the approach to resolution, including ensuring the plan and approach is understood
- Coordination of internal GitLab and customer resources to drive troubleshooting and resolution of the issue
- Management of customer and internal communications, both async and synchronous
- Ownership of next steps, ensuring these are determined, communicated clearly with appropriate timelines to meet the level of urgency

### Escalation (For Non Professional Services Projects)

- The DRI is responsible for managing the account engagement (not the ticket), including:

  - Management of internal team and customer meetings for follow-up activities
    - Note: To ensure the DRI does not slow the resolution of issues, the DRI doesn't need to be in all meetings (for example, technical troubleshooting with the customer and support/development)
  - Driving and coordinating the escalation process internally and with the customer, including associated communications and executive-level meetings
  - Opening or reviewing the CS Help - Escalation Support case in Salesforce
  - Managing all assigned escalation tasks in Gainsight
  - Acting as an escalation point for customer-related issues (for example, delayed response, open actions, non-compliance installation or product use, etc.)
  - Developing the business case justification and escalation to Product for escalations related to enhancement requests
  - Posting updates to Gainsight timeline, which will trigger notifications to both the temporary Slack channel and the `#escalated_customers` slack channel

- Support Engineering is responsible for:

  - Collaborating with technical resources (for example, Development, Quality Assurance, SREs, and Support Engineering staff) to drive resolution of the technical issues
  - Managing the 24x7 incident resolution and escalation process (Support Engineering, SRE, Development)
  - Supporting executive and customer calls (as needed)

If an escalation is opened as high or critical, and the escalation is product related, a Product DRI is required. Please assign the applicable Product DRI from this [list](https://docs.google.com/spreadsheets/d/124nDAb7p6yViLCsEHaqQTcDTMMT2-FPxeTwZxKOyLwM/edit?gid=0#gid=0).

### What's the difference between an account escalation or an incident escalation?

- This page describes the account level risk meaning the customer impacting issues could be a single incident or an aggregation of issues. The assessment considers impact to the customer, risk to future business with that customer, and GitLab brand.
- Technical Support is ultimately accountable for driving resolution to the support case, including escalation to Engineering, Security, and/or Infrastructure teams.  Incident escalation processes should be leveraged for a single incident / support case.

- [Declare a GitLab.com Incident](/handbook/engineering/infrastructure-platforms/incident-management/#report-an-incident-via-slack) if you suspect a widespread issue on GitLab.com
- [Escalate an individual support ticket to Support Management](/handbook/support/internal-support/support-ticket-attention-requests) for cases with context that necessitate they should be handled outside of standard priority order.
- Have the customer [trigger Emergency Support](https://about.gitlab.com/support/#how-to-trigger-emergency-support) for S1/instance down issues to connect directly with the Support Engineer on-call.
  - You can also [page the on-call support manager](/handbook/support/on-call/#engaging-the-on-call-manager) in cases where you've received word that a customer attempted to raise an emergency, but the on-call engineer was not paged.
- This page outlines the additional support and operational procedures for the varying levels of account escalation.

## Initiating, Managing and Closing an Escalation

The following steps are to be taken by the escalation DRI:

### Opening the Escalation

__Immediately__

1. Open or review the [CS Help request](#cs-help-request)
      1. If a CSM is the DRI, open the CS Help - Escalation Support case
      1. If a regional CSE leader is the DRI, review the CS Help - Escalation Support case that was opened by an AE, RM, SA, or other GitLab employee who identified the escalation.
1. Create a [slack channel](#temporary-slack-channel) to facilitate communication internally at GitLab during the escalation.
1. [Identify Escalation DRI and immediate asks](#identify-escalation-dri-and-immediate-asks)
1. Watch for the auto [escalation declaration](#declare-the-escalation) in `#escalated_customers`.

__Within 24 hours__

1. Set up and document an [internal standup cadence](#internal-standup-cadence) series while the escalation is running and put the details in the escalation case.

__Ongoing__

1. Post updates in the Gainsight case CTA according to the cadence described in the [definitions of severity levels](#definitions-of-severity-levels).
1. Keep exit criteria and DRIs up to date in the [CS Help request](#cs-help-request)

#### Temporary Slack Channel

This channel will remain open until the escalation is closed and should be listed in the escalation case. Name the channel #esc_customername (must start with #esc_ to be included in our data retention policy) and ensure it is a public channel so that relevant internal GitLab parties can be easily added/find the channel. Some more tips & tricks for opening and managing the temporary slack channel can be found below:

- a. Create an opening message in the escalation channel which should include the link to the escalation case + the initial ask. Also link to the customer notes doc.
  - Example for a potential opening message to get things going:
    - "*Welcome! This is the channel for the <CUSTOMER_NAME> escalation regarding ongoing performance problems which are impacting the whole user base.*"
      - *The escalation case is ready and available at "<*LINK*>"*
      - *The initial ask/need from DRI (CSM) to GitLab management is defined in the escalation case - Quote:*
        - "*We need a GitLab team (member) who can engage with the customer on a daily basis to further analyze the performance issues root cause(s) and identify potential changes to reduce the performance problems for the  users.*"
        - "*Once the root causes are identified, we need a team working with the customer to implement required changes, which may range from configuration updates to changing the architecture of the GitLab platform or involving cloud vendor support for changes in underlying infrastructure.*"
    - "Whats next?"
      - "Our next sync with the customer team is scheduled for Monday at 10:30am CEST where we would like to have the team (member) defined internally, who can then be introduced to the customer (can be a separate call at afternoon time) to engage in the following days."

- b. If posted, pin the opening message to the channel, so that it is easily available for everyone. Also add the escalation case link as a SLACK channel bookmark.

#### CS Help Request

If an [Escalation (For Non Professional Services Projects)](#escalation-for-non-professional-services-projects) has been identified, create an escalation case in Salesforce. Steps for opening the case:

1. Navigate to the account page in Salesforce
1. Navigate to the next open renewal opportunity under "Opportunities". It helps to sort the list of opportunities by "Close Date" descending. (Note: if you're having trouble finding the opportunity, you may need to change the Salesforce App. Click the 9-dotted box in the upper left corner and change the Salesforce App to "Sales")
1. In the top right corner, click on "Request Support" and then in the drop down field on "CS Help"
1. Select the case type: Escalations (CSM/CSE Accounts)
1. Fill out the required fields in the Escalation Case, including the link to the Internal Customer Escalation Slack Channel that was previously created.
1. For the required field "Internal Customer Escalation Slack Channel" paste the Slack channel link (not just the channel name). To get this link, hover over the #esc_customername channel in Slack and right-click, then go to Copy > Copy Link. Paste this link in the required field in Salesforce.
1. Click "Create case"
1. Complete other fields in the opened case: Customer Collaboration project, Customer meeting notes, Escalation Exit criteria. At this time, you can also edit any of the fields initially filled out when opening the case.

For a CSM Managed account, the Case Owner will be the assigned CSM. For a CSE account, the Case Owner will be the regional CSE leader.

The Salesforce case will create a Gainsight CTA for that particular customer, which can be found in the Gainsight Cockpit. A sync between Salesforce and Gainsight happens every 2 hours. Once the Gainsight CTA is created, the Case Owner will receive Gainsight notifications to complete required tasks. Data is bidirectional between Salesforce and Gainsight, so changes can be made in either tool. However, all escalation updates must be made in the Gainsight CTA by adding Timeline entries of type "Health Update" (which is the same Timeline entry type used for Red Accounts management).

#### Internal Standup Cadence

Set up and document an internal standup cadence series while the escalation is running and put the details in the escalation case.

- Major stakeholders from each team involved in the escalation should be invited directly to any calendar invite.
- Post about the internal standup in the temporary slack channel.
- Post the escalation case URL in the temporary slack channel and pin the message so it's easy to find.
- Tip: 10min before each standup, post the link to the escalation case and customer notes doc with a note that the standup will happen at the scheduled time. You can also schedule & automate the message in SLACK.

During the internal cadence, be sure to note any changes in exit criteria or DRI and make those changes in the escalation case.

#### Identify Escalation DRI and immediate asks

Make sure you write down the initial ask & needs (to initially make progress) in this escalation, as clearly as possible and add a [bookmark](https://support.google.com/docs/answer/45893?hl=en&co=GENIE.Platform%3DDesktop#zippy=%2Ccreate-a-bookmark) to it. You can link to it in the initial message within the [escalation slack channel](#temporary-slack-channel) channel. As mentioned, be as specific as possible, as the GitLab exec / management team needs to understand the escalation exit criteria.

For example:

- Required skills (Remote EMEA Timezone)
- Ability to analyze production logs
- Familiarity with large-scale production architecture for GitLab
- Ability to understand SQL queries
- Familiarity with PostgreSQL, Patroni, PGBouncer

#### Declare the escalation

After the escalation case is opened in Salesforce, a post will be automatically added to the `#escalated_customers` channel to declare the escalation. This process is followed for all except PubSec customers, where you will need to manually post the escalation using the following template:

- New Escalation
- __Customer__: "<customer_name>"
- __Slack Channel__: "#<esc_customername>"
- __Meeting Notes__: "<LINK: customer meeting notes>"
- __SFDC Escalation case URL__: "<LINK: escalation case>
- __Severity__: High
- __Status__: Opened
- __Product DRI__: "[Assigned Product DRI](https://docs.google.com/spreadsheets/d/124nDAb7p6yViLCsEHaqQTcDTMMT2-FPxeTwZxKOyLwM/edit?gid=0#gid=0)"
- __Support DRI__: "If support involvement is necessary use the @support-manager-oncall slack handle. Please ensure a support ticket is opened with a description of the issue. Support will engage with Engineering by following their [RFH process](/handbook/support/workflows/how-to-get-help/#how-to-formally-request-help-from-the-gitlab-development-team)."
- __Description__: "<Example <Customer> platform is impacted by performance problems since several weeks and users are affected on a daily base which is driving the customer into a critical state. The performance problems are also risking their our license expansion.>"
- __FYI__: "<TAG_YOUR_MANAGER_HERE>"

If the escalation is product related, a Product DRI is required. Please assign the applicable Product DRI from this [list](https://docs.google.com/spreadsheets/d/1x44kzJE4_Ixj20utn4g5Mggn1Jc3kKMWaY16F2WmLWg/edit#gid=242012002). The Product DRI should be added to the #esc_customername channel and will drive any product related items throughout the escalation.

### Managing the Escalation

The DRI owns the functions as outlined here:

- If an escalation status changes significantly, ensure that updates are captured in the Gainsight Escalation CTA > Timeline > Activity Type = "Health Update".
- Select "Update" in the "Post to Slack" field dropdown, which will be used to trigger an automated notification to be sent to the `#escalated_ customers` channel. This hourly process is followed for all except PubSec customers, where you will need to post the update manually.
- Apply the "Escalation Update" Timeline template (selectable from top right hand corner of the "Notes" box in Timeline) to ensure consistency of the information presented in escalation updates.
- The Gainsight Escalation Update Timeline template questions are :

1. What is the current status of the escalation?
1. What are the next steps in moving the escalation case forward?
1. Who is the owner of the next steps?
1. Has the exit criteria for this escalation changed? If so, what is the new exit criteria?

- Be sure to also post in the temporary customer slack channel, pinging all DRIs involved in the escalation as needed.
- Update the temporary escalation slack channel daily, at minimum
- The escalation progress should also be communicated to the customer on a regular basis - expectation is 3 or more times a week depending on the situation.

Tips & Tricks:

- Create a daily reminder (at afternoon before you leave, for example) in your Google calendar just for yourself to update the escalation case + temporary slack channel with latest status/next steps. This ensures everyone is kept informed.
- Depending on the state of the escalation, also think about setting up an internal cadence meeting and include all necessary team members.
  - CSM, AE, SA, CSM & Sales leadership, and potentially other involved stakeholders.

#### Multiple escalations for one customer

In rare instances, there may be multiple reasons for a customer to be escalated at one time. In order to keep the reasons for escalation and the steps to resolve them focused, there should be an escalation for each situation. Each escalation should be declared and separate Slack channels opened with the relevant stakeholders involved. The reason for the escalation should be included the channel name to reduce confusion (e.g. if one customer is escalated for both a DAST issue and a performance issue, there should be two channels, one called esc_customername_dast and one called esc_customername_perf). Each escalation should follow the defined escalation process separately, but the account team and leadership should stay aligned on where the overall account health is throughout and if there should be any action that relates to both escalations. Including additional leadership such as the e-group may be warranted if there is significant risk to the overall sentiment of the account.

## Tracking Escalation Engagements

Escalation management is critical work that directly impacts customer renewals and satisfaction. To ensure this work is visible and measurable, CSMs must track their escalation engagement activities in Gainsight. This allows leadership to understand the time investment required for escalations and recognize this work in performance reviews.

### Why Track Escalation Engagements?

- __Visibility__: Make escalation work visible to leadership and in performance metrics
- __Accountability__: Document the time and effort CSMs invest in managing escalations
- __Reporting__: Enable dashboards and reports showing escalation volume, time spent, and outcomes
- __Recognition__: Ensure escalation management is recognized as high-value customer advocacy work

#### How to Log Escalation Activities

CSMs should log all escalation-related activities (calls, emails, internal coordination, updates, etc.) in the __Timeline tab of the Escalation CTA__ in Gainsight. This is different from posting status updates to the customer timeline.

__Step-by-step process:__

1. __Open Gainsight and navigate to the Cockpit view__
   - This is where you manage all CTAs for your accounts

2. __Select the specific Escalation CTA__
   - Find the escalation CTA that was auto-created from the Salesforce escalation case
   - The CTA will be named based on the escalation case

3. __Navigate to the Timeline tab within the CTA__
   - Once inside the CTA, click on the Timeline tab

4. __Log your escalation activities__
   - Add timeline entries for all escalation-related work:
     - Customer calls and meetings
     - Internal coordination calls with engineering, support, product, or leadership
     - Email communications with the customer
     - Status updates and progress notes
     - Any other actions taken to drive escalation resolution

#### Visualization of the Escalation Engagement Tracking Flow

```mermaid
flowchart TD
    Start([CSM needs to log<br/>escalation work]) --> SFDC[SFDC Escalation Case Created]
    SFDC -->|Auto-creates| CTA[Escalation CTA in Gainsight]
    
    CTA --> Cockpit[CSM opens Cockpit view<br/>in Gainsight]
    Cockpit --> Select[Select the specific<br/>Escalation CTA]
    Select --> Timeline[Navigate to Timeline tab<br/>within the CTA]
    Timeline --> Log[Log activity:<br/>• Updates<br/>• Calls<br/>• Emails<br/>• Other actions]
    
    Log --> Report[Activities linked to<br/>Escalation CTA]
    Report --> Dashboard[Reports & Dashboards<br/>show escalation effort]
    Dashboard --> Visibility[Management visibility<br/>of escalation work]
    
    style Start fill:#e1f5ff
    style SFDC fill:#fff4e1
    style CTA fill:#fff4e1
    style Cockpit fill:#e8f5e9
    style Select fill:#e8f5e9
    style Timeline fill:#e8f5e9
    style Log fill:#e8f5e9
    style Report fill:#f3e5f5
    style Dashboard fill:#f3e5f5
    style Visibility fill:#f3e5f5
```

#### Important Notes

- __Start immediately__: Begin logging activities as soon as the escalation is opened, so all coordination work is captured from the start
- __Be specific__: Include details about what was discussed, decisions made, and next steps in each timeline entry
- __Current limitation__: Gainsight timeline entries do not currently track actual time spent (hours/minutes). Timeline entries only capture a start date/time. Once Gainsight adds time-tracking capabilities, CSMs will be able to log hours spent on escalation activities
- __Distinction from Health Updates__: Health Updates (status updates about escalation progress) are separate from engagement activities. Both should be logged in the CTA Timeline, but engagement activities provide granular tracking of CSM work

### Closing the Escalation

- To close an escalation, a clear alignment between GitLab stakeholders and the customer (including documentation in an issue or email) is required. Both parties need to agree the situation is resolved.

- If the customer requests an RCA and the escalation was platform-related, GitLab engineering will lead the RCA and will provide it in writing to the corresponding GitLab DRI, who is managing & closing the escalation.

- When the issue(s) related to the escalation are resolved or move into a non-escalated state:

  - In Gainsight, navigate to your account, then to the `Cockpit` tab. Find the CTA that was created for the escalation and open it.
  
  {{< figure src="/images/handbook/customer-experience/csm/escalations/gainsight-cockpit-tab.png" alt="Gainsight account page showing the Cockpit tab" >}}

  - Within the CTA, navigate to its `Timeline` tab. Click `Add Activity` and select `Health Update` for the `Activity Type`. Then click `Apply Template` and use the `Escalation Closure` timeline template.
  
  {{< figure src="/images/handbook/customer-experience/csm/escalations/gainsight-cta-timeine-entry-escalation-closure.png" alt="Gainsight CTA Timeline tab showing the Add Activity dialog with Health Update selected and the Apply Template option" >}}

  - Select `Closure` in the `Post to Slack` field dropdown, which will be used to trigger an automated notification to be sent to the `#escalated_ customers` channel. This hourly process is followed for all except PubSec customers, where you will need to post the escalation closure update manually.
  - Archive the temporary Slack channel
  - Update the customer's CSM Sentiment in Gainsight to reflect the new state of the account.

- Gainsight Escalation Closure Timeline template questions:

- Please provide a closure update answering the following questions:

1. Did the escalation situation end with a positive outcome, negative outcome, or no outcome?
1. Were the defined exit criteria met?
1. Give a brief summary of the actions of the team that helped close out this escalation ticket

## CSM Manager's role in Escalations

The CSM Manager's responsibility is to ensure that the CSM is familiar with the above process and is actively managing the escalation, including the Slack Channel updates and the management of the escalation doc.

When a customer is in an escalated state, the path to resolution must continue to move forward, with both the internal stakeholders and the customer clear on current actions and next steps. The CSM manager is responsible for ensuring that this forward-motion and clear alignment is present and for stepping in and driving action or alignment where necessary.

## Engineering's role in Escalations

Engineering support will usually come through Support Engineering, however it's worth noting that under some conditions [Engineering / Product may prioritize bug fixes and feature requests](/handbook/engineering/#critical-customer-escalations) related to an escalation.

## Product's role in Escalations

At times Product may be needed to support an escalation. This could be due to uncovering a flaw or issue or surfacing feedback to help influence prioritization or workarounds to address the escalations. In most cases CSM and Support will work directly with a PM responsible for the area.

Occasionally, customers will require a product leader to act as a stable counterpart to support an escalation. This will ensure customers don't need to understand how we're organized, or need to get bounced around between PMs during an escalation. To achieve this we will follow this process:

1. CSMs will evaluate each account that reaches a high or critical escalated state, and determine if a Product member is needed.
1. From there, if the escalation reaches a High state a Group Product Manager or Product Director will be assigned. If it reaches a critical state a PLT member will be assigned.
1. During the escalation the GMP+ Product leader will stick with the customer and escalation and operate as a stable counterpart. They will bring in additional PMs as needed to help address the concerns, but will remain engaged in Slack, and on calls with the customer to be a consistent face and representative of the Product division.
1. Individual PMs may roll in and out of the escalation but the assigned GMP+ product counterpart will remain attached until the escalation is resolved.

## CSE's role in Escalations

If necessary, a regional CSE leader will request a CSE to support on an escalation. The CSE should work with the regional CSE leader to determine next steps.

## Related Links

- [Support Engineering Page](/handbook/support/) and [Support Engineering Escalation Procedures](/handbook/support/workflows/working-with-issues/)
- [Product Escalation Issue Template](https://gitlab.com/gitlab-com/Product/issues/new?issuable_template=Product-Support-Request) to request Product Team support for roadmap / future needs, prioritization of enhancements and/or issues and troubleshooting of customer issues.
- [Customer Health Assessment and Account Triaging](/handbook/customer-experience/csm/health-score-triage/)
