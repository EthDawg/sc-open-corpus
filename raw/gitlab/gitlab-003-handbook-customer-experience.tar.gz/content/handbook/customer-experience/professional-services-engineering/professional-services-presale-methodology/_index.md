---
title: "Professional Services Pre-Sales Methodology"
description: “Discover how GitLab Scopes Professional Services can fit into the Customer Journey during the presales cycle.”
---

## PS Process & Methodology Mapped to the Customer Journey

The Professional Services process and methodology fits within the Customer journey that is supported by Customer Success.Professional Services contributes to the customer journey from the point of **SOW Close** through the **Project Close** phase.

We have Directly Responsible Individuals (DRIs), Activities, Outcomes, and Tools/Collateral for each stage of the methodology. We can also see clear categorization of stages in pre-sales and post-sales phases.

All of this is captured in the [Professional Services internal handbook page](https://internal.gitlab.com/handbook/customer-experience/professional-services/).

## Pre-Sales Overview

The purpose of this page is to document the sales-assisted selling motion used by Professional Services Engagement Managers and Regional Delivery Managers. If you're on a GitLab sales account team looking for information, try these pages on [positioning professional services](/handbook/customer-experience/professional-services-engineering/positioning) or [selling professional services](/handbook/customer-experience/professional-services-engineering/selling/#custom-scoped-services).

This page outlines when and how to get involved with positioning and scoping services, how the estimate and SOW are built, and how they are approved.

> *Note: Services engagements can take [two forms](/handbook/customer-experience/professional-services-engineering/selling). This will focus on the **custom SOW scoping** process, not the Standard SKU process.*

For custom SOWs, the [workflow for SOW creation](/handbook/customer-experience/professional-services-engineering/selling/#custom-scoped-services) involves a partnership between the Account Team and the Professional Services Team.

[Source, GitLab Team Members Only](https://docs.google.com/presentation/d/1TOI2aoseBoyWYQC6-xpJVMknEncCNreSFfMvOHO7EBA/edit#slide=id.gbfb62d0c00_0_58)

## 1. Positioning

- **DRI**: Account Team (SAE/AE, SA, CSM)
- **Supported By**: Engagement Manager

### MEDDPICC

Professional services can be positioned when a prospect becomes a customer (e.g. the Land of a new deal) or when an already existing customer is growing their staff or interesting in adopting new features of GitLab (e.g. expansion). The SA, SAE, AE, or CSM (e.g. "Account Team") is primarily responsible for this process, following the [Command of the Message](/handbook/sales/command-of-the-message/) and [MEDDPICC](../../../sales/meddppicc.md) messaging frameworks.

For the larger, more strategic customers PS Engagement Managers tend to get involved earlier in the selling process to help with discovery and provide lessons learned on rollout from past engagements. For the medium sized customers, Engagement managers tend to get involved with account teams when the SFDC stage 4 (Proposal) is achieved.

### PS Opp Qualification

As the overall subscription deal is progressing, the account team should begin to qualify in or out an attached professional services opportunity. They can do this with some [simple scripts](/handbook/customer-experience/professional-services-engineering/positioning/#value-of-gitlab-professional-services) to first establish value of professional services. Next they should ask qualifying questions like:

1. How do you plan to execute the upcoming transition onto the GitLab platform?
1. Who will manage this, both from a technical perspective and a change management standpoint?
1. What will that person or people be de-prioritizing to drive this?
1. Have those people worked with the intricacies of such a transition in the past?
1. How do you plan to surface and manage risks throughout the transition period?

If the customer is uncertain to any of these questions, you can assert that it might make sense to bring in the PS Engagement Manager in to scope the engagement as an option to help derisk the rollout of GitLab and maximize the value/impact of the subscription purchase.

### AE Creates PS Only Opp in SFDC

Once its identified that the customer will likely want to engage with professional services, its the responsibility of the Account Team to [get in touch with the Engagement Manager](/handbook/customer-experience/professional-services-engineering/engagement-mgmt/#how-to-contact-or-collaborate-with-us).

## 2. Scoping

- **DRI**: Engagement Manager
- **Supported By**: PS Practice, Account Team (SAE/AE, SA, CSM)

### Gather Data

When the Account Team creates the PS opportunity, a scoping issue is created automatically. Using the scoping issue and the estimate in PS Compass, the engagement manager gathers data asynchronously from the account team. Questions about the potential engagement can sometimes be answered by the Account Team from the discovery that was done already. We want to make sure we avoid asking duplicate questions to the customer. In some cases when the account team cannot provide the level of detail to create an engagement, the EM will meet with the Account team and Customer to ask additional discovery questions to get to a level of detail needed.

### Create Engagement Estimate

The Engagement Manager builds the estimate in PS Compass, GitLab's internal estimating tool. They choose the services in scope from the PS service catalog and estimate the effort for each activity. The services we offer are listed on our [offerings framework](/handbook/customer-experience/professional-services-engineering/framework) page.

### Iterate / Review Engagement Estimate

After the first iteration of building detail into the straw-man, the Engagement manager posts a request for review in the [professional services slack channel](/handbook/customer-experience/professional-services-engineering/working-with/#slack) to the Account team. Often the Engagement Manager will get on a zoom call with the customer and provide context and gather feedback from the customer.

### Generate SOW

Once the Engagement Manager has buy-in from the account team and/or customer on the size and activities included in the services engagement, they generate the SOW from the estimate in PS Compass.

### Iterate/Review SOW Data

Once the SOW is generated, it is ready for review by the account team. Iteration can occur here but should be minimized if the proper iteration was done on the Straw-man Steps.

### SOW Review/Approval

After one or more rounds of iteration on feedback from the account team, the SOW goes through GitLab's internal contract approval workflow, including PS Leadership review. GitLab team members can find the details in the internal [contracting and quoting](https://internal.gitlab.com/handbook/customer-experience/professional-services/contracting-and-quoting/) page.

## 3. Delivery Prep

- **DRI**: Project Manager
- **Supported By**: EM, PM, PSE, TA, Account Team

Once the engagement moves to stage 6, `awaiting signature` in salesforce, the engagement manager schedules an intro meeting between the PM and the customer stakeholder to discuss "how we manage projects at GitLab".  During this call, the PM will also discuss resource assignment, and scheduling details. Simultaneously, the PM will schedule an internal transition meeting with the EM, PM, PSE, TA, and Account Team to review the technical discussions that occurred during the customer scoping meetings.  This is a opportunity for the entire team to discuss and disclose the inner workings and dynamics of the customer project team.

### PM Introduction

Engagement managers introduce the PS Project Manager as they are in contract with the customer during the scoping exercise and are perfectly positioned to do so.

### Resource Identification

The PS Proejct Coodinator, working closely with the Regional Delivery Manager, will identify the best resource to deliver the project based on skillset, timezone, personality, tenure, and availability.

### Project Prep call

This is a call between the customer stakeholder and the PS Project Manager to discuss HOW we work.  Where we track project progress, what status report will look like, what the meeting cadence might be, a review of the contract terms that affect how we work such as minimum hours per week, expiration dates, delay language, and most importantly, how to achieve mutual agreement with the customer on a preliminary project schedule, prior to the kick-off call which includes the entire project team.

Check out the PS Delivery methodology to understand the details around pre-sales handoff to the delivery team, to ensure a successful relationship and productive engagement.

### 4. SOW Execution/Close

- **DRI** Engagement Manager
- **Supported By**: PS Leader, Sr. PSE, SAE/AE, Legal, Finance, Deal Desk

### Approval and Signature

The Engagement Manager sends the SOW from PS Compass to GitLab's contract workflow, where it is reviewed and approved internally (including PS Leadership, Revenue and Legal) and redlines from the customer are worked through. Once approved, the SOW is sent to the customer for signature. GitLab team members can find the details in the internal [contracting and quoting](https://internal.gitlab.com/handbook/customer-experience/professional-services/contracting-and-quoting/) page.

### Deal Desk updates SFDC

Once the SOW is fully executed, the deal desk team updates the Salesforce PS-Only opportunity to `closed-won`.
