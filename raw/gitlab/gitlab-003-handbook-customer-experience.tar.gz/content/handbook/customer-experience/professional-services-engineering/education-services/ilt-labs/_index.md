---
title: "GitLab Professional Education Services ILT Labs"
description: "Lab Exercises for the Education Services ILT courses"
---

## Current Offerings

The GitLab Professional Education Services team currently provides the following offerings:

- [Live Instructor-led training (ILT)](https://about.gitlab.com/services/education/)
- [GitLab Technical Certifications](/handbook/customer-experience/professional-services-engineering/gitlab-technical-certifications/) as Professional Service offerings.
- [Train-the-Trainer](https://university.gitlab.com/pages/train-the-trainer-training/)
- [Seminar Training](/handbook/customer-experience/gitlab-training-seminar/)
