---
title: "Professional Services Engagement Management"
description: "Describes the workflow and responsibilities of the GitLab Professional Services Engagement Manager."
---

## Role of the Engagement Manager

The [Professional Services (PS) Engagement Manager](/job-description-library/sales/job-professional-services-engagement-manager/) is responsible for developing services proposals that helps Customers achieve their intended outcomes. The process typically includes the following activities.

- An initial meeting with the Customer to understand current state, constraints and desired outcomes
- Build the initial estimate in PS Compass, GitLab's internal estimating tool
- Create a proposal with current understanding, desired outcome, methodology, timeline, customer responsibilities, and price
- Update the estimate/proposal based upon feedback from the Customer
- Once agreed, generate a supporting contract - either an order form or Statement of Work (SOW)
- Review risks across Program Management and Technical delivery domains
- Gain PS Leadership, Legal and Revenue approval
- Gain Customer approval
- Route contract for signature
- Capture delivery information to provide Resource/Delivery Managers

## Meet the Team

Check out our team of Engagement Managers on our [team page](/handbook/company/team/?department=practice-management)

## How to contact or collaborate with us

- AEs can create a `professional services only` opportunity in SFDC. This triggers the automatic creation of a scoping issue used for collaboration during PS discovery, scoping and proposal presentation.
- [Slack](/handbook/customer-experience/professional-services-engineering/working-with/#slack) for informal and general questions, coordination
- Salesforce Chatter for approvals, discussion of opportunity status, or collaboration with sales leadership and legal.

## Useful Resources

- [Services to Accelerate Customer Adoption](/handbook/customer-experience/professional-services-engineering/sales-enablement/)
- [Selling Professional Services](/handbook/customer-experience/professional-services-engineering/selling/)
- [Professional Services Offering Framework](/handbook/customer-experience/professional-services-engineering/framework/)
- [Certified GitLab Engagement Manager Learning Journey](gitlab-certified-engagement-manager)
- [Main Customer Slide Template](https://gitlab.highspot.com/items/629a6d7cf089bbaa9e0d4fa7?lfrm=srp.0)
- [Services data sheets](https://gitlab.highspot.com/search?q=data+sheet)

## Engagement Manager - Processes

- [Engagement Scoping Information](scoping-information/)
- For GitLab team members, the detailed scoping, estimating and SOW process is in the internal handbook: [identify, scope and estimate](https://internal.gitlab.com/handbook/customer-experience/professional-services/identify-scope-estimate/) and [contracting and quoting](https://internal.gitlab.com/handbook/customer-experience/professional-services/contracting-and-quoting/)
- [Quote Creation process for opportunities with both Custom Services and Fixed Price Training on a single SOW](/handbook/sales/field-operations/sales-operations/deal-desk/#creating-a-professional-services-quote-for-scopedcustom-education-or-services)
- [Transacting ProServ business through AWS Marketplace](aws-marketplace/)
