---
title: "Professional Services Engagement Management - Transacting ProServ business through AWS Marketplace"
description: "Describes the workflows for processing a SOW through AWS Marketplace."
---

Processing a PS Opportunity through AWS Marketplace

See [internal handbook page](https://internal.gitlab.com/handbook/customer-experience/professional-services/contracting-and-quoting/#aws-marketplace) for details
