---
title: "Working with Professional Services"
description: "Discover how to work with the GitLab Professional Services Team."

---

### How to Contact Professional Services

At GitLab, Professional Services (PS) is part of the [Customer Success department](/handbook/customer-experience/). As such, you can engage with PS by following the guidelines for engaging with any [Solutions Architect (SA)](/handbook/solutions-architects/processes/#engaging-an-sa-during-the-sales-cycle). This process ensures that the Customer Success department as a whole can understand the inbound needs of the account executive and our customers.

#### Slack

PS uses the [#professional-services](https://gitlab.slack.com/archives/CFRLYG77X) slack channel to answer generic questions about services and to signal delivery of PS scoping work items like PS Engagement Estimates and SOWs.  The private [#professional-services-us-pubsec](https://gitlab.slack.com/archives/C025UHLTR50/p1625778195002900) slack channel is used for US Public Sector services.  Please request access to [#professional-services-us-pubsec](https://gitlab.slack.com/archives/C025UHLTR50/p1625778195002900) in [#professional-services](https://gitlab.slack.com/archives/CFRLYG77X).

#### Requesting training for GitLab team members

**For team leads**

Internal GitLab team leads can request training sessions delivered by Professional Services for their teams. Here are the steps for making a request.

1. [Create a new issue](https://gitlab.com/gitlab-com/customer-success/professional-services-group/education-services/-/issues/new?issue%5Bassignee_id%5D=&issue%5Bmilestone_id%5D=#) in the Education Services namespace using the internal_trainer_request issue template. or internal-team-member-training-request
1. Complete the Requestor Tasks in the issue description.
1. The PS Project Coordinator will reach out to plan and schedule the training session(s).

**For individual team members**

Individual GitLab team members can request to audit a customer-facing training sessions delivered by Professional Services. Here are the steps for making a request to attend.

1. [Create a new issue](https://gitlab.com/gitlab-com/customer-success/professional-services-group/education-services/-/issues/new?issue%5Bassignee_id%5D=&issue%5Bmilestone_id%5D=#) in the Education Services namespace using the internal-team-member-training-request template.
1. Complete the Requestor Tasks in the issue description.
1. The PS Project Coordinator will confirm the date(s) with you and provide you with a registration link.

### For Sales Reps and SAs: How to order Professional Services

1. To order Professional Services, the SAE or ISR [creates a child PS Opportunity in SFDC off of a standard license or subscription parent opportunity](/handbook/sales/field-operations/gtm-resources/#creating-a-professional-services-opportunity) using the `Create Services Opportunity` button.

1. The next steps depend on whether the services needed are standard or custom.

- **Standard Services (non-customized)**: Sold using Professional Services SKUs with pre-defined statement of work (SOW) documents. These offerings do not require custom scoping and are ordered directly from Zuora in SFDC. Checkout our [full catalog](https://about.gitlab.com/professional-services/catalog/) for a list of standard services currently offered.

- **Custom Services**: Sold if standard services do not meet the needs of the customer, using a custom SOW. Please contact your [Professional Services Engagement Manager based on region](https://docs.google.com/document/d/1bdVOf3jL6aJF79qRMFLQsmMxIgQh5ZQ-WiLuNgsWB08/edit?tab=t.0#heading=h.qzgxpwqxme5). When creating the PS Opportunity in step 1 above, a [Professional Services Epic](https://gitlab.com/groups/gitlab-com/customer-success/professional-services-group/-/epics?state=opened&page=1&sort=start_date_desc) will automatically be created for you as well as a [scoping issue](https://gitlab.com/gitlab-com/customer-success/professional-services-group/ww-consulting/ps-plan/-/issues/?sort=created_date&state=opened&first_page_size=100). Please use the epic and issue to input information and collaborate with your Engagement Manager.

**Process for Sales Reps and SAs**

```mermaid
graph LR;
  a["Standard services?"]-- Yes ---b["Add SKU to quote"];
  a-- No ---c["AE/SA auto creates PS epic with Create Services Opportunity button"];
  c-->d["AE/SA works w/PS to finalize SOW"];
  z["Send customer proposal"];
  d-->z;
  b-->z;
```

![create-services-opportunity.png](/images/customer-experience/professional-services-engineering/working-with-ps/create-services-opportunity.png)

For more details on selling professional services, see [Selling Professional Services](/handbook/customer-experience/professional-services-engineering/selling).

For information on how to position Professional Services to your customer, see [Positioning Professional Services](/handbook/customer-experience/professional-services-engineering/positioning).

#### Lead time for starting a Professional Services Engagement

Often we are asked "what is your lead time for getting started with a project" or a customer may have a specific timeframe in which they want a project delivered.
As there may be many projects and proposals in flight at any time, there are a few rules we use when prioritizing and scheduling engagements:

- No engagement schedule can be committed to until the PS Opportunity is closed/ won and the PS Operations team has scheduled the project. While we can make a good faith effort to try and match a schedule ahead of that time, to be fair to customers who have committed to a services engagement we must prioritize those first.
- Please, check with the PS Operations Team by tagging the group `@ps-scheduling` for the latest lead time details in the [professional services slack channel](#slack) if you need a more accurate estimate.
- The PS Operations team does review projects that are SFDC Stage 5.  As we strive to start the projects within days of the SFDC Stage of closed/won.

#### Custom services SOW creation and approval

For custom services, the Professional Services Engagement Manager partners with the account team (SAE/AE, SA, CSM) to scope the engagement with the customer. The Engagement Manager builds the estimate in PS Compass, GitLab's internal estimating tool, reviews it with the account team and the customer, and then produces the SOW. All custom SOWs are approved by PS Leadership before they are released to the customer for signature.

We prefer customers to mark up our agreement and SOW document if they request changes. If they require the use of their own services terms or SOW, please contact the PS team.

GitLab team members can find the detailed process in the internal handbook: [identify, scope and estimate](https://internal.gitlab.com/handbook/customer-experience/professional-services/identify-scope-estimate/) and [contracting and quoting](https://internal.gitlab.com/handbook/customer-experience/professional-services/contracting-and-quoting/).

### Scheduling Professional Services

Currently, customer projects are scheduled in order as the opportunity is Closed-Won.  Please discuss any concern about scheduling the project during the Discovery phase of the scoping process. As part of the Discovery phase, please update the Project Scheduling Intake issue. The Project Coordinator will use this information to review staffing. If there are lead time or availability questions, please ask the Engagement Manager or Project Coordinator by tagging the group @ps-scheduling in the professional services slack channel (#professional-services).
Please do not commit any project start dates prior to the SOW/contracts being signed without confirming with the PS Project Coordinator.

Once the opportunity is updated to Close/ Won, here are the next steps:

- The PS Project Coordinator will review the SOW and Order Form and work to set up the project in Kantata
- The PS Project Coordinator will reach out the account team for the customer contacts if the information has not been provided in the Project Scheduling Intake issue.
- The PS Project Coordinator will send a Welcome to PS email within 72 business hours of the opportunity booking to the customer and copy the account team and Professional Services leaders.
