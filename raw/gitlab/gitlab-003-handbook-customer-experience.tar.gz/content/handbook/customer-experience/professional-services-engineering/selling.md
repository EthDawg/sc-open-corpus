---
title: "Selling GitLab Professional Services"
---

You can also [watch the sales enablement session](/handbook/customer-experience/professional-services-engineering/sales-enablement) about how to sell services.

For internal team members, please look at the detailed [internal handbook page](https://internal.gitlab.com/handbook/customer-experience/professional-services/) to understand the end to end Professional Services process.

## A Note on Partner Professional Services

Please remember to follow the [Rules of Engagement for Selling Professional Services](/handbook/sales/selling-professional-services) with the following highlights:

- Always start by finding out if your customer/prospect has a qualified and preferred professional services partner and start by engaging with that partner to explore a solution for your customer/prospect
- **SMB** clients are welcome to purchase [SKU offerings](https://about.gitlab.com/services/catalog/). Please route all custom **SMB** needs through professional services Channel Partners as outlined in the [ROE](/handbook/sales/selling-professional-services). Please see additional detail in the FAQ below.
- Remember to update the SFDC Professional Services Opportunity to **"closed lost"** if for any reason after you have created a GitLab Professional Services Opportunity in SFDC the work is transitioned to being sold and delivered by a partner.  Then make sure that any Services Attach Registration that the partner registers for that work is attached to the relevant Licensing Opportunity in SFDC.  Please work with the Channel Account Manager for the partner (found in SFDC account for the partner) if you have any questions about this process.

## Workflow for GitLab selling Professional Services

There are 4 main steps for selling GitLab Professional Services:

1. Identify the right services needed.
1. Ensure the appropriate license or child opportunity exists in SFDC ([details below](#step-2-create-the-opportunity-in-sfdc)).
1. Reach out to [your Professional Services Engagement Manager](https://docs.google.com/document/d/1bdVOf3jL6aJF79qRMFLQsmMxIgQh5ZQ-WiLuNgsWB08/edit?tab=t.b4x70ea3f0er#heading=h.qzgxpwqxme5) to build a proposal deck, estimate, quote, and SOW, as needed, or help positioning Professional Services in general.
1. Confirm the quote and close the opportunity.

```mermaid
graph LR;
  a["Standard services (SKU), no SOW?"]-- Yes ---b["Add SKU to quote"];
  a-- No ---c["AE auto creates PS epic with Create Services Opportunity button"];
  c-->d["AE/SA works w/PS EM to finalize pitch, estimate, SOW, and quote"];
  z["Send order form or SOW to Customer for closure"];
  d-->z;
  b-->z;
```

### Step 1: Identify the right service

The AE can find the general services the PS team offers on the [full catalog](https://about.gitlab.com/professional-services/catalog/). The AE can pull the SA/CSM in for help selecting services needed based on customer requirements.

### Step 2: Create the opportunity in SFDC

The AE [creates a Professional Services Only opportunity](/handbook/sales/field-operations/gtm-resources/#creating-a-professional-services-opportunity).

### Standard Services Only

If the customer only needs standard services from the service catalog, the AE can generate the quote from within the newly created SFDC PS opportunity by:

1. Click `New Quote`.
1. Choose the proper billing account. In the _Quote Type_ section Select `New Subscription`. Click `Next`.
1. On the _Create New Subscription Quote_ screen, update required fields (e.g. _Start Date_) as needed. Click `Next`.
1. On the _New Quote Flow_ screen, click the drop down box next to the _New Quote Flow_ and select `Add Add on Products`.
1. In the `Professional Services and Training` Row, click the drop down that says `Select Plan` to see the current SKU offerings that can be added to the opportunity. Click `Next`.

After following the above process steps, click `Generate PDF` to obtain an Order Form to share with the customer for signature.  The AE should meet with the customer to review the service deliverables, duration, and pricing and should confirm no customizations are needed. Again, they can pull in the EM for assistance if needed.

### Custom-Scoped Services

If the account team (AE/SA/CSM) determines that the customer requires additional services outside of those listed in the [full catalog](https://about.gitlab.com/services/catalog/), they should initiate the creation of a PS epic and associated scoping issue by using the `Create Services Opportunity` button from a standard parent license or subscription opportunity to create a child PS Opportunity. This will add an issue to [your assigned PS Engagement Manager's](https://docs.google.com/document/d/1bdVOf3jL6aJF79qRMFLQsmMxIgQh5ZQ-WiLuNgsWB08/edit?tab=t.0#heading=h.qzgxpwqxme5) queue to follow up with you on next steps. Check out the [detailed steps below](#custom-scoped-services-detailed-workflow) for custom-scoped engagements for more details.

### Instructions for creating a Professional Services Quote

Deal Desk with require a quote for either Service option above.  How to create a quote can be found [here](/handbook/sales/field-operations/sales-operations/deal-desk/#quoting-professional-services).

### Step 3: Reach out to your PS EM to Position and Close Service Opp

For standard SKUs, the Order Form is generated directly from SFDC via the quote object [here](/handbook/sales/field-operations/sales-operations/deal-desk/#quoting-professional-services). Upload the signed version of this document when you receive it from the customer.

For custom scoped SOWs, Professional Services Engagement Managers should be brought into conversations with the Customers to help pitch professional services and provide accurate estimates. Once you receive the SOW from your assigned Engagement Manager and have gotten it back from the customer with signature, attach it to the SOW doc to the SFDC PS opportunity.

### Step 4: Close the opportunity

### Closed Won

Once the services have been rendered and the project is closed, the SAE/ISR should obtain signatures from the customer. The SAE/ISR should move the opportunity to `Closed Won` status

As the agreement approaches `Closed Won`, make sure to request `@ps-scheduling` to  identify a potential start date in the [professional services slack channel](/handbook/customer-experience/professional-services-engineering/working-with/#slack) given the [typical lead times for starting a PS engagement](/handbook/customer-experience/professional-services-engineering/working-with/#lead-time-for-starting-a-professional-services-engagement).

### Transitioned to a Partner - Closed Lost

Remember to update the SFDC Professional Services Opportunity to **"closed lost"** if for any reason after you have created a GitLab Professional Services Opportunity in SFDC the work is transitioned to being sold and delivered by a partner.  Then make sure that any Services Attach Registration that the partner registers for that work is attached to the relevant Licensing Opportunity in SFDC.  Please work with the Channel Account Manager for the partner (found in SFDC account for the partner) if you have any questions about this process.

### Custom-Scoped Services Detailed Workflow

1. Account team: Create a child PS Opportunity from a standard license or subscription parent opportunity using the `Create Services Opportunity` button.
1. SA/CSM: Add initial scoping details to the automatically generated scoping issue around customer requirements
1. SA/CSM & PS Engagement Manager: Conduct detailed scoping call with the customer
1. PSEM: Develop Custom SoW and pricing for customer
1. Account team: Deliver SoW to the customer, add to the Salesforce (SFDC) opportunity
1. Send for signature (just like software terms)
1. When Closed Won, the PS team will handle staffing. Average lead times are updated weekly -  please check with the EM to set expectations with the client

## FAQ

### Do we have set SKUs I can use?

Yes - for off the shelf items, we have [SKUs](https://about.gitlab.com/services/catalog/).

### What are our daily or hourly rates?

We do not currently have an hourly or daily rate.  Nor do we plan to have an hourly rate.  Just as with GitLab support, the mission of our Professional Service group is not to bill hours, but to achieve success for our Customers.  So just as we don't offer support by the call or by the hour, we do not offer Professional Services by the day or the hour.

In the future, we may have a daily rate or a daily rate for on-site support.  However, we currently do not for the same reasons listed above.

### What if the customer only wants training?

If the customer is an EE customer, we can offer training. We have training SKUs also listed in the SKU link above as well as in [GitLab University](https://university.gitlab.com/learn/dashboard). However, custom training will need to be scoped out by the Customer Success department before quoting a price. The account executive will also be required to provide the use case for the need for just training.

Example use case might be:

- Customer is under license utilization and we need to prevent churn, help expand usage into additional groups and other business units.

### What options exist for CE Customers?

GitLab CE is ideal for personal projects or small groups with minimal user management and workflow control needs.  Because these groups don't typically need a lot of focus on scaled implementation or training, we currently do not offer implementation, integration or training services to our CE customers.  Many of our [partners](https://about.gitlab.com/partners/) offer such services.  However, we find that many customers who have been running a CE instance and are looking to transition to a scaled implementation of GitLab may require a [Discovery Engagement](/handbook/customer-experience/professional-services-engineering/offerings/#discovery-engagement) to determine the customer's long-term needs.

If a customer is upgrading from CE to EE, Professional Services should be engaged to scope out the requirements for the transition if the customer will need services in the transition.

### What options exist for SMB Customers?

SMB customers often do not have sufficient budget for our professional services offerings, and we traditionally try to meet their needs through [channel partners](https://about.gitlab.com/partners/). If your client had budget for one or more of our [SKUs](https://about.gitlab.com/professional-services/catalog/), you are welcome to attach the SKU and do not need to create a scoping issue with the professional services team.

Please note: Migrations to GitLab SaaS currently require the use of an admin token, which is unavailable to partners. Therefore, these migrations **must** run through our GitLab professional services team currently.
