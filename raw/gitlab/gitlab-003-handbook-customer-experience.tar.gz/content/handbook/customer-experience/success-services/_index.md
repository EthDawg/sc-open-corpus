---
title: Success Tiers


---

GitLab's Success Tiers are paid service offerings that provide customers with dedicated technical expertise, structured enablement programs, and enhanced support. Each tier is designed to match different levels of customer need, from on-demand pooled resources to a fully designated team.

The Success Tier team can be reached in [Slack channel](https://gitlab.enterprise.slack.com/archives/C05US54ETB3) (internal only).

For content for positioning the value of the tiers, how to price/quote the tiers and how to handle objections, please visit the internal handbook page [Success Services (aka Success Plan Services)](https://internal.gitlab.com/handbook/customer-experience/success-services/).

## Tier Overview

| Tier | Assigned Resource | Accelerators | Training Discount | Certification Vouchers |
|------|-------------------|:------------:|:-----------------:|:----------------------:|
| **On-Demand** | Pooled [CSE](/handbook/customer-experience/csm/segment/cse/) | — | — | — |
| **Essentials** | Designated [CSM](/handbook/customer-experience/csm/) | — | 5% | 20 |
| **Advanced** | Designated [CSA](/handbook/customer-experience/csm/segment/csa/) | 2/year | 10% | 40 |
| **Signature** | Designated [CSA](/handbook/customer-experience/csm/segment/csa/) + [ASE](/handbook/support/enhanced-support-offerings/offering-assigned-support-engineer/) | 4/year | 20% | 60 |

- **On-Demand** is available to all GitLab customers. CSEs deliver pooled webinars, hands-on labs, and office hours.
- **Essentials** provides a named CSM who owns your success plan, cadence calls, and renewal strategy.
- **Advanced** provides a named CSA with deeper technical expertise and structured Accelerator programs.
- **Signature** adds an Assigned Support Engineer (ASE) alongside the CSA for the highest level of white-glove support.

To get started with a paid Success Tier, visit [about.gitlab.com/services/](https://about.gitlab.com/services/).

## What Is an Accelerator?

An Accelerator is a 12-week structured enablement program delivered by your CSA, aligned to your mutual success plan. Each Accelerator follows a four-phase lifecycle: **Discovery → Design → Deliver → Measure**. Accelerators are included with the Advanced (2/year) and Signature (4/year) tiers.

For a full list of available Accelerator programs, see the [Accelerator Catalog](/handbook/customer-experience/success-services/accelerator-catalog/).

## Customer-Facing Roles

| Role | Tier | Description |
|------|------|-------------|
| [Customer Success Engineer (CSE)](/handbook/customer-experience/csm/segment/cse/) | On-Demand | Technical product experts delivering pooled, on-demand enablement to all customers |
| [Customer Success Manager (CSM)](/handbook/customer-experience/csm/) | Essentials | Designated advisor driving adoption, success planning, and renewal strategy |
| [Customer Success Architect (CSA)](/handbook/customer-experience/csm/segment/csa/) | Advanced / Signature | Highest-rated technical experts delivering architecture guidance and Accelerator programs |
| [Assigned Support Engineer (ASE)](/handbook/support/enhanced-support-offerings/offering-assigned-support-engineer/) | Signature | Dedicated support engineer providing proactive monitoring and accelerated incident resolution |

For a side-by-side comparison of all CS and SA roles, see the [CS & SA Roles Overview](/handbook/customer-experience/roles-overview/).

## Success Tiers

### Overview

Our Success Tiers drive adoption and value realization of GitLab products whilst providing customers with Best Practices and a higher tier of White Glove support. We achieve this by bundling an [Assigned Support Engineer (ASE)](/handbook/support/enhanced-support-offerings/offering-assigned-support-engineer/), [Customer Success Architect (CSA)](/job-description-library/sales/customer-success-architect/)/[Customer Success Manager (CSM)](/handbook/customer-experience/csm/#what-is-a-customer-success-manager-csm-at-gitlab) and Education services into a single SKU as an annual renewable service.

The [Assigned Support Engineer (ASE)](/handbook/support/enhanced-support-offerings/offering-assigned-support-engineer/) is the primary point of contact for their customers and will  triage any support ticket logged by that customer and is included with the Signature Tier. Over time, because of this consistent resourcing, the knowledge of the customer's needs, environment and architecture results in faster resolution times to the most common logged issues.

The [Customer Success Architect (CSA)](/job-description-library/sales/customer-success-architect/) is accountable for their customer's success through GitLab product adoption using well understood Best Practices.  CSA's bring deeper product knowledge and technical depth than the industries traditional CSM role.  With experience across many customers, they are experts at ensuring features are leveraged the right way for maximum value.   This customer experience has lead to development of best practice content and prescriptive road-maps.  This content is folded into the Success Tiers offerings as "Accelerators".

> Customer Success is not permitted to be "Hands on Keyboard" with customers.   We can and do provide best practices, architectural guidance and will tailor adoption and success plans to a specific customer need.  If a customer needs GitLab to develop a bespoke solutions or actively change or manage their configuration, we will need to engage our [Professional Services](/handbook/customer-experience/professional-services-engineering/) team.

Education Services included with Success Tiers encompasses 1 day of Instructor-led Training as well as a significant number of Training Certification Exam vouchers.   This enables us to partner the running of specific accelerators, aligned to training and certification, to ensure your team is ready and able to drive the cost benefits that GitLab brings.

### Success Tiers Resources and Support

#### 1. Success Tiers Qualification Framework

We've created a [comprehensive framework](https://gitlab.highspot.com/items/68138e0af1e7d5daacbfcfae#1) to help sales teams effectively position and sell Success Tiers. This framework provides:

- Clear qualification criteria for each tier
- Value propositions tailored to customer needs
- Structured objection handling responses
- Customer success stories by segment

#### 2. Regional Champion Support

Regional Champions are available to provide expert guidance on positioning Success Tiers.

##### How to request support

1. Navigate to the [#success-tiers](https://gitlab.enterprise.slack.com/archives/C05US54ETB3) Slack channel
2. Click on **Workflows** at the top of the channel
3. Select **Success Tier - Request for Help**
4. Specify if you need:
    - Live call support
    - Positioning guidance
    - Quick brainstorming session

##### Regional contacts

- **EMEA**: {{< member-by-gitlab "kgoossens" >}}
- **AMER**: {{< member-by-gitlab "Tiffanymcatee.gitlab" >}}
- **APJ**: {{< member-by-gitlab "catherineballantyne" >}}
- **Escalations**: {{< member-by-gitlab "kgeorgeson" >}}

### Success Tier Customer Onboarding

```mermaid
graph LR
    A[Order Form Received] --> B[<b>Welcome Email Sent</b><br><i>24hrs after resources identified</i>]
    B --> C[<b>Internal Account Team Handover</b><br><i>within first week</i>]
    C --> D[<b>Customer Kick-Off Call</b><br><i>within first 1 to 2 weeks</i>]
    D --> E[<b>Accelerator Begins]
```

Note that you may be onboarding an account which is not net new. To ensure smooth collaboration and handover with the account team, it is advised to consult the responsibility matrix [issue](https://gitlab.com/gitlab-com/customer-success/success-services/csa/-/issues/16)

### Success Tier Customer Onboarding Artifacts

1. Introduction Email
   1. This email will be sent within 24hrs of both CSA and ASE resources being identified and as close as possible to Order Form being received from Customer.
   2. Utilize the appropriate welcome email template -
      1. [Signature | Success Tiers - Welcome Email](https://gitlab.highspot.com/items/67fe720d040d7ec85356346f#2)
      2. [Advanced | Success Tiers - Welcome Email](https://gitlab.highspot.com/items/67fe720f040d7ee3c8b160a1?lfrm=srp.2)
      3. [Essentials | Success Tiers - Welcome Email](https://gitlab.highspot.com/items/67fe7212040d7ea6e1af7af0?lfrm=srp.6)
   3. The first priority is getting the kick-off call locked in so that you can review the program and get in front of the customer

### Success Tier Customer Onboarding Activities

1. Internal Kick-off Call
   1. Internal prep call for the CSA to perform knowledge transfer and coordinate with the account team on what is the priority work to wrap an accelerator around.
   2. The purpose of this call is to discuss the customer objectives between the account team and the CSM/A, which should identified prior to the Order Form being signed.
      - Account Context & Technical Documentation Template
         1. The Template helps standardize the documentation of critical customer information, technical configurations, stakeholders, and strategic objectives gathered during account onboarding to ensure consistent knowledge capture and enable effective handoffs between CS team members.
         2. Utilize [this internal template](https://docs.google.com/document/d/1uIcF7sBN84vyyfzikmMm_GrDgcjOyhB8SVkkWYque78/edit?usp=sharing) and customize to your customer's needs
            - Tip: you can organize a playback/walkthrough meeting with your account team (SA, CS) to validate your understanding prior to the kick-off call
         3. This template should help you structure and play back your understanding of the account to your SA/CS team, creating a foundation for discovery workshops and collaboration projects by capturing key business drivers, technical requirements, and stakeholder priorities in a standardized format that can be easily validated and expanded upon.

2. Customer Kick-off Call
   1. This will be scheduled within the first week of the agreement, subject to customer availability.
   2. If the customer is not available in the first week for a formal kick-off, both ASE and CSA should begin work asynchronously and will start any needed conversations through email.
   3. Utilize the appropriate kick-off deck & customize as needed (internal).
      1. [Signature | Success Tiers - Kickoff Deck](https://gitlab.highspot.com/items/67fe720b1d0a83d481b69449#1)
         - [Demo](https://gitlab.highspot.com/items/680f8ee83cc2d050572efa00)
      2. [Advanced | Success Tiers - Kickoff Deck](https://gitlab.highspot.com/items/67fe7209be150cb32b8b47f2?lfrm=srp.9)
         - [Demo](https://gitlab.highspot.com/items/680b978897caecb740bc6504)
      3. [Essentials | Success Tiers - Kickoff Deck](https://gitlab.highspot.com/items/67fe7205040d7eb57aaf784c?lfrm=srp.8)
         - [Demo](https://gitlab.highspot.com/items/6812783bf1e7d50ea1f7888a)
   4. Share the `.pdf` version post-call as well as immediate next steps, such as a sudiscovery workshop.

3. Discovery Workshop
   1. The outcome of this workshop is to gain an in-depth understanding of the customer's business objectives/success metrics, technology stack, and processes.
   2. This is the first step in defining a success plan with the customer as well as identifying a potential accelerator backlog to work on.
   3. Tip: Run the discovery workshop within two weeks of the kickoff call to enable triage of accelerator development backlog items and provide feedback to the customer. Leverage this interaction to get a baseline for DORA metrics you will be impacting with your accelerator development.
   4. Utilize this [intake questionnaire](https://gitlab.com/gitlab-com/customer-success/success-services/csa/-/issues/15) as a starting point. Here is an example of a discovery document created for one of our customers: [internal discovery document](https://docs.google.com/document/d/1yf1RGS-pNGccHfGiiIVsvg8VL56ctJNSMZDeRLT1eDs/edit?tab=t.0#heading=h.azdjicqpfuh9).

### GitLab University Panorama

GitLab University Panorama is a dedicated, managed learning portal included with the **Signature Success Tier**. Customers who have purchased GitLab University Enterprise separately also qualify. It provides SSO integration, custom content hosting, and customer-specific reporting — giving your team a centralized hub for GitLab training and certifications.

**Key talking points for onboarding**

During the onboarding conversation, discuss:

- **Learning priorities**: What are their top 3 focus areas? (e.g., CI/CD, AI/Duo, Security)
- **Authentication**: Do they prefer SSO (requires IT involvement) or a simpler registration code?
- **Certifications**: How many certification vouchers did they purchase?
- **Custom content**: Do they want to host internal training materials alongside GitLab courses?
- **Reporting**: Who should have admin access to view usage dashboards?

Once you've gathered customer preferences, follow the [GitLab University Panorama request workflow](/handbook/customer-experience/success-services/glu-panorama/) to submit the formal request. Setup typically takes 5 business days.

### Post Onboarding

#### CSM Processes

See [High-Level Responsibilities of a CSM](/handbook/customer-experience/csm/#high-level-responsibilities-of-a-csm)

#### CSA Processes

We have CSA specific processes that go above and beyond the CSM role. It is expected that this is layered on top of the CSM processes and responsibilities.

##### Accelerators

Success Tiers include up to 4 Accelerators for the Signature tier and 2 for Advanced, that your [Customer Success Architect (CSA)](/handbook/customer-experience/csm/segment/csa/) will deliver.

> An accelerator is a customized form of enablement that a GitLab CSA will define and deliver to a customer. These accelerators span a quarter and they're mapped to your mutual success plan.

An Accelerator, depending on customer requirements and defined outcomes, will pull together one or more of the below content modules.   Typically the accelerator runs over 12 weeks.  It kicks off with a discovery workshop to document required customer outcomes.  From that, we will run a planning workshop outlining with the customer the steps necessary to achieve their outcomes.   The output of the Planning Workshop is a backlog of issues logged, in a GitLab project, that includes all the necessary activities that will be managed over the following 10 weeks to achieve those outcomes and close out the Accelerator

![Accelerator Timeline](/images/customer-experience/success-services/accelerator-timeline-graphic.png "Accelerator Timeline")

###### Accelerator Content Modules

| Category | Content Modules | Description | Outcome|
|---|---|---|---|
|CI/CD|Introduction to CI/CD Workshop|The Intro to CI accelerator for the CI Pipeline track is a Getting Started/How to accelerator, focused on building initial familiarity and basic understanding of usage of GitLab CI for users who are new to the platform.|You'll come away understanding the architecture of GitLab ci.yml and GitLab runners, how to create a gitlab-ci.yml, as well as common patterns and rules|
|CI/CD|Runner fleet guidance  |A Customer Success accelerator to optimize and manage a GitLab Runner fleet at scale.|Your CSA will walk through a maturity assessment, informational sessions and interactive training including|
|CI/CD|Rules and pipeline flow|The Rules & Pipeline Flow accelerator for the CI Pipeline track is an Advanced Concepts accelerator, which covers methods of defining the flow of a pipeline using rules, DAG, parent/child pipelines, and any other optimization methods to control the operations of pipelines.|Training that is delivered with best practices|
|CI/CD|CI templates and reusability|The Templates & Reusability accelerator for the CI Pipeline track is an Advanced Concepts accelerator, covering the creation and use of CI templates and optimization of the workflow.|Best practices that have been tailored to your level of maturity|
|CI/CD|Product coach|The Product Coach accelerator for the CI Pipeline track is a Deep Dive accelerator, focused on consultative guidance on best practices and pipeline optimization for customer pipelines.|Your CSA will provide a detailed "guidance report" with 20+ categories to optimize your pipeline|
|CI/CD|Pipeline Template Optimization|Provides a structured 12-week program that optimizes CI/CD implementation through the development of standardized, reusable templates tailored to your organization's specific project types, languages, and compliance requirements.|By the end of this accelerator, you'll achieve measurable efficiency gains with developers spending less time implementing pipelines and more time delivering value, improved organization-wide compliance through standardized practices, and a sustainable framework for ongoing pipeline management and governance.|
|Security and Compliance|Intro to security workshop|60 - 90 minute presentation of security concepts, security features, and getting started recommendations|Customer will be appraised of security scanners, vulnerability dashboards, and how to begin using these features|
|Security and Compliance|Hands-on security lab|90 - 120 minute, hands-on lab that you will have access to a gitlab.com sandbox; we provide the code and have prescriptive steps to configure security and compliance features|Customer will come away with actual experience adding security scanners to a pipeline, configuring security policies and compliance frameworks, and how to triage vulnerabilities|
|Security and Compliance|Ultimate Onboarding|This series provides comprehensive guidance on implementing robust security practices, from initial setup exploration through advanced scanning implementation, policy configuration, and vulnerability management strategies tailored to your organization's needs. |By the end of this accelerator, you'll have a fully configured GitLab security framework with optimized scanning capabilities, customized governance policies, and efficient vulnerability management workflows that significantly reduce risk across your development lifecycle.|
|Security and Compliance|Intro to audit, compliance, and separation of duties workshop|60 - 90 minute presentation of audit concepts, compliance and security policy features, and best practices|Your CSA will tailor this content to your needs and maturity; you'll come away with knowledge that'll allow you pass audits, institute consistency across your groups, and recommendations for where to go next|
|Security and Compliance|Security rollout strategy|This content module will provide a complete plan for rolling out security and compliance features; including timelines and milestones that are mutually agreed upon with GitLab's best practices |The result of this content module will be a presentation of the rollout strategy and how it maps to your outcomes and timelines; additionally, the milestones and tasks will be in the collaboration project backlog so that your CSA can continue to guide on the rollout process|
|Security and Compliance|Product Coach - Compliance Framework/Security Policies Audit|The Product Coach accelerator for the Security & Compliance track is a Deep Dive accelerator, focused on consultative guidance on best practices for security policies, developer workflow, and separation of duties|Your CSA will spend weeks learning your existing workflow and then provide a guidance report that will have best practices and recommendations|
|Security and Compliance|Security Policy Rollout Strategy|The Security Policy accelerator for the Security & Compliance track is a multi-quarter program that your CSA will guide you through. The work is broken out into 5 phases: Architecture & Design, Compliance, Audit & Enablement, Dashboards & Integration, and Scaling. |By following our best practices, you'll be able to have a standardized and auditable GitLab instance. [Internal material](https://drive.google.com/drive/folders/1r_d1Lk5RyKoPvdN9HmzNKhHhAfKsSVAh) the CSA will leverage.|
|Agile Planning|Intro to GitLab Plan workshop|Overview of GitLab issue management and backlog workflows|Your teams will come away with an understanding of all the backlog planning features, reporting, and best practices|
|Agile Planning|Jira + GitLab workshop|This workshop will detail the options you have when integrating Jira and GitLab|Your CSA will spend time discovering your current needs and setup; then they'll deliver a customized workshop catered to your outcomes|
|AI/ML|AI/ML hands on lab|Bootstrap your developers on all the AI/ML features GitLab has and how to use them|Your team will walk away being familiar with how to invoke all the AI features and suggested usages for them; they will also have access to a gitlab.com sandbox for 3 days to keep experimenting|
|AI| Duo Enterprise Onboarding | This accelerator delivers a comprehensive 12-week program that strategically implements AI-powered development tools across your organization through customized demonstrations, guided adoption strategies, and ongoing expert support tailored to your specific workflows and team structures|By program completion, you'll achieve measurable improvements in development efficiency with active adoption across multiple Duo features, a self-sustaining internal champion network, and quantifiable gains in key metrics including cycle time reduction, code quality improvements, and enhanced security posture.|
|System administration|Upgrade package|This deep dive accelerator will prepare your system administration team for upcoming upgrades|The outcome will be a detailed upgrade plan, a presentation on the deprecations as well as new features you need to be aware of, and a collaboration project to track any and all questions you have leading up to the upgrade|
|System administration|Managing Monorepos & Large Repositories |Addresses performance challenges in oversized repositories through comprehensive optimization of repository structure, Git LFS implementation, and CI/CD pipeline efficiency tailored to your specific environment and developer workflows.|Measurable improvements in repository performance with reduced clone and fetch times, optimized storage utilization, streamlined CI/CD pipeline execution, and sustainable maintenance procedures that enhance overall developer productivity and support continued repository growth.|
|System administration|Optimizing Platform Resiliency |Enhances your GitLab platform's protection against cyber threats through structured implementation of security hardening, backup strategies, incident response planning, and policy controls tailored to your organization's critical digital assets.|By the end of this accelerator, you'll achieve a significantly more resilient GitLab environment with enhanced security monitoring, validated backup and recovery capabilities, documented incident response procedures, and implemented security policy controls that ensure business continuity and protection of your crown jewel repositories.|

<br>

### Recording Success Tier Timeline Activities in Gainsight

Consistently recording key Success Tier activities in Gainsight is essential to our customer success operations. This documentation ensures that all team members follow standardized procedures when logging customer interactions.

Accurate activity tracking in Gainsight enables:

- Complete visibility into customer engagement history
- Accurate reporting on Success Tier delivery metrics
- Better collaboration across teams working with the same customer
- Data-driven insights to improve our Success Tier offerings
- Continuity of service during team member transitions

By following these guidelines, we maintain a reliable system of record that supports both operational efficiency and strategic decision-making.

#### General Instructions (Applies to All Activities)

To record any activity in Gainsight, start by navigating to the customer's account taking you to their C360. Then, depending on the context of the activity:

- **For activities related to a Call to Action (CTA)**:
   1. Click the Cockpit tab within the account
   2. Select the specific CTA to which the activity applies
   3. Add the activity from the Timeline tab on the actual CTA to ensure proper association

- **For activities related to a Success Plan**:
   1. Click the Success Plan tab in the account navigation
   2. Select the relevant Success Plan
   3. Click on the Cockpit tab
   4. Click on the desired Objective you wish to log an activity
   5. On the top-right side, click on the Timeline tab
   6. Click Add Activity to relate the entry to the Success Plan

- **For general activities** (not related to a CTA or Success Plan):
   1. Click the Create button in the top right corner from anywhere in the account

##### Specific Activity Types

###### Kick-off Call

1. Navigate to the correct area in Gainsight as described in the general section above.
2. Once the Activity Timeline Entry form is open, select either **Customer Call** or **In-Person Meeting** from the Activity Type dropdown list.
3. Select the **Kickoff** option in the Meeting Type dropdown list.
4. Fill out the remaining fields with all relevant information.
5. Click **Log Activity** when finished.

###### Accelerator

1. Navigate to the correct area in Gainsight as described in the general section above.
2. Once the Activity Timeline Entry form is open, select **CSA Engagement** from the Activity Type dropdown list.
   - Note: Any activity logged under this type will be considered an Accelerator.
3. Fill out the remaining fields with all relevant information.
4. Click **Log Activity** when finished.

###### Workshop

1. Navigate to the correct area in Gainsight as described in the general section above.
2. Once the Activity Timeline Entry form is open, select **Workshop** from the Activity Type dropdown list.
3. Fill out the remaining fields with all relevant information.
   - **Important**: While not required fields, it's highly recommended to log:
      - External Attendees
      - Workshop topic
4. Click **Log Activity** when finished.

###### Executive Business Review (EBR)

1. Navigate to the correct area in Gainsight as described in the general section above.
2. Once the Activity Timeline Entry form is open, select either **Customer Call** or **In-Person Meeting** from the Activity Type dropdown list.
3. Select **Executive Business Review** from the Meeting Type dropdown list.
4. Fill out the remaining fields with all relevant information.
   - **Important**: Complete as many fields as possible, as this information is critical for reporting purposes.

Click **Log Activity** when finished.
