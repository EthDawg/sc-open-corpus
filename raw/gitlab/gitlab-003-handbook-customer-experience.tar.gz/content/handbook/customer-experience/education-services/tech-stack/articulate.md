---
title: "Articulate 360 Tech Stack Guide"
description: "Tech Stack Guide for Articulate 360 Content Authoring tool."
---

The [Tech Stack](/handbook/business-technology/tech-stack-applications/) is the single source of truth and contains more detail about this app.

### Implementation

The Implementation of this system took place in March of 2020 and is currently used by the following departments: Education Services, Technical Marketing, Field Enablememt, Learning and Development, and Recruiting.

### System Diagram

The Articulate 360 tool is a SaaS app and is not integrated with other GitLab systems.

### Data Model

The Data Model is not available and Articulate 360 is a closed system.

### Integrations

The Articulate 360 tool is a SaaS app and is not integrated with other GitLab systems.

### Key Reports / Dashboards

All Dashboards and Reports are a part of system itself. No separate Sisense reports are available or planned.

### Support Guides and Step by Step Articles

The [Articulate 360 Support page](https://training.articulate.com/videos) offers a docs website with full articles on processes and step by step guides on using the system.
