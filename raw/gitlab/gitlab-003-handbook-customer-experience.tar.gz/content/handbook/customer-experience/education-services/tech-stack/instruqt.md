---
title: "Instruqt Tech Stack Guide"
description: "Tech Stack Guide for the Instruqt Virtual Lab system"
---

The [Tech Stack](/handbook/business-technology/tech-stack-applications/) is the single source of truth and contains more detail about this app.

### Implementation

The Instruqt implementation for GitLab is still underway and has not been full implemented.

### System Diagram

The Instruqt Implementation is a SaaS app and is integrated with the [Thought Industries LMS](/handbook/customer-experience/professional-services-engineering/education-services/lms/)

```mermaid
graph TD
A[Thought Industries LMS] -->|User name and email| B(Instruqt)
B -->|Virtual Labs completed| C[Completion data transferred back to Thought Industries]
```

### Data Model

The Data Model is not available and Instruqt is a closed system.

### Integrations

The Instruqt Implementation is a SaaS app and is integrated with the [Thought Industries LMS](/handbook/customer-experience/professional-services-engineering/education-services/lms/)

### Key Reports / Dashboards

All Dashboards and Reports are a part of system itself. No separate Sisense reports are available or planned.

### Support Guides and Step by Step Articles

The [Instruqt Support page](https://docs.instruqt.com/) offers a docs website with full articles on processes and step by step guides on using the system.
