---
title: "GitLab Projects Baseline Requirements"
description: "The hb page outlines baseline configurations that must be set up for GitLab projects which impact the GitLab codebase."
toc_hide: true
tags:
  - security_standard
  - security_standard_cmma
---

## Purpose

The purpose of this page is to outline a minimum set of requirements that must be met by the projects defined in [Scope](#scope). The end goals are that no changes that ultimately impact the GitLab codebase can be made without independent review, and that the risk of vulnerabilities and supply chain attacks reaching production is reduced. This page can also help users of GitLab by offering some possible configurations for securing projects they deem critical.

Given GitLab's [commitment to dogfooding](/handbook/engineering/development/principles/#dogfooding) and keeping in mind GitLab's Efficiency Value it is important to understand that these baseline project configurations are not required on *all* projects, only those projects defined in [Scope](#scope) or otherwise deemed critical for another communicated reason (note in these instances the rationale of the "why" behind the need for these baseline configurations should be able to be clearly communicated).

That said, it is encouraged for team members to keep these baseline configurations in mind when creating or working in projects as they are designed to improve the security and quality of contributions made in GitLab projects.

## Scope

These baseline configurations must be applied to any project that influences the GitLab codebase directly or indirectly and/or that impacts the build, release or deployment of GitLab. This includes projects that contain production code, infrastructure, container builds, or CI/CD pipelines that deploy software contributing to GitLab the product.

Examples of a project that fits this criteria:

- A project that builds a component of GitLab
- A project that builds a bot which helps manage the codebase for a component of GitLab
- A project used for updating a critical non-GitLab system's codebase (e.g. Salesforce)

Examples of a project that *do not* fit this criteria:

- A project that has no code
- A project that builds a bot which doesn't impact the GitLab codebase (e.g a script to convert a YAML file into a CSV)

Project usage may naturally shift over time and it's important to be re-evaluating project usage on an ongoing basis, projects may go in and out of either category so please keep that in mind as you work in projects each day. The hope is that even when a project does have these baseline configurations setup, efficiency isn't decreased as we have team members collaborating on work and avoid working in silos of knowledge that increase our risk of an individual becoming a single point of failure as well. These values also encourage our Transparency Value by getting multiple team members involved in changes.

### I'm not sure where my project fits

That's okay! And certainly not going to be uncommon. If you have questions, please raise them so we can address and try to fit into the appropriate category. We can iterate here on how we categorize projects so we ensure our commitment to Security and Quality, as well as Efficiency.

### My project doesn't fit seem to fit the criteria but I still need these configurations?

There also may be instances when a project doesn't strictly meet our general criteria for requiring baseline configurations but for some reason it is determined that the project should be configured using the baseline configurations. In these instances the rationale of the "why" behind the need for these baseline configurations should be able to be clearly communicated. If many similar rationales are being provided for projects that don't appear to meet the existing criteria, it is likely an indicator that the scope and criteria of projects should be adjusted.

## Baseline requirements

Projects defined in [Scope](#scope) must meet all requirements below. Teams may apply stricter controls.

1. <a id="protected-branch-baseline-configurations"></a>**Protect branches.**
   - [Require merge requests for protected branches](https://docs.gitlab.com/user/project/repository/branches/protected/#require-everyone-to-submit-merge-requests-for-a-protected-branch) instead of direct pushes.
   - [Disable force-pushes to the default branch](https://docs.gitlab.com/user/project/repository/branches/protected/#allow-force-push-on-a-protected-branch).
   - Enable the [Reject unsigned commits push rule](https://docs.gitlab.com/user/project/repository/push_rules/#require-signed-commits).
   - Enable the [Reject unverified users push rule](https://docs.gitlab.com/user/project/repository/push_rules/#verify-users), so a commit's committer email must be a verified email on the pusher's account.
   - Enable the [Reject inconsistent user name push rule](https://docs.gitlab.com/user/project/repository/push_rules/#verify-users), so a commit's author name must match the pusher's GitLab account name when the author and committer emails are the same.
   - Enable the [Check whether the commit author is a GitLab user push rule](https://docs.gitlab.com/user/project/repository/push_rules/#verify-users).
   - Enable [Do not allow users to remove Git tags with `git push`](https://docs.gitlab.com/user/project/repository/push_rules/#prevent-unintended-consequences). Tags remain deletable through the UI and the API, so pair this with protected or immutable tags.
   - Enable the [Prevent pushing secret files push rule](https://docs.gitlab.com/user/project/repository/push_rules/#prevent-pushing-secrets-to-the-repository). This rule matches file names, so it complements rather than replaces secret push protection, which scans file contents.

1. <a id="mr-approval-rule-configurations"></a>**Require review and approval.**
   - Follow GitLab's [Code Review Guidelines](/handbook/engineering/workflow/code-review/).
   - Configure [merge request approval rules](https://docs.gitlab.com/user/project/merge_requests/approvals/rules/) to prevent merging unreviewed commits.
   - In **Settings > Merge requests**, set **Approvals required** to 1 for the [**All eligible users** rule](https://docs.gitlab.com/user/project/merge_requests/approvals/rules/#code-owners-as-approvers). Then every merge request needs one approval from someone other than the author, even when there isn't a Code Owner who can approve it. See [How the approval rules combine](#how-the-approval-rules-combine).
   - Enable [Remove all approvals](https://docs.gitlab.com/user/project/merge_requests/approvals/settings/#remove-all-approvals-when-commits-are-added-to-the-source-branch) when new commits are added.
   - Enable [Prevent approval by merge request creator](https://docs.gitlab.com/user/project/merge_requests/approvals/settings/#prevent-approval-by-merge-request-creator).
   - Enable [Prevent approvals by users who add commits](https://docs.gitlab.com/user/project/merge_requests/approvals/settings/#prevent-approvals-by-users-who-add-commits).
   - Enable [Prevent editing approval rules in merge requests](https://docs.gitlab.com/user/project/merge_requests/approvals/settings/#prevent-editing-approval-rules-in-merge-requests).
   - Require human approval when law, regulation, or contract requires it, including applicable SOX or FedRAMP controls.

1. <a id="note-on-usage-of-code-owners"></a>**Require Code Owner approval.**
   - [Define file ownership in a Code Owners file](https://docs.gitlab.com/user/project/codeowners/#codeowners-file).
   - Add a catch-all line like `* @group/owners` in its own section, using your team's group in place of `@group/owners`. The `*` gives every file a Code Owner.
   - Enable [Code Owner approval](https://docs.gitlab.com/user/project/repository/branches/protected/#require-code-owner-approval) on every protected branch.
   - Require approval from at least one Code Owner when a merge request changes files they own.
   - Avoid [exclusion patterns (`!`)](https://docs.gitlab.com/user/project/codeowners/reference/#exclusion-patterns) and [optional sections (`^`)](https://docs.gitlab.com/user/project/codeowners/reference/#optional-sections) for files that require Code Owner review.

1. **Protect against secret leaks.**
   - Enable [secret push protection](https://docs.gitlab.com/user/application_security/secret_detection/secret_push_protection/).

1. **Restrict token access.**
   - Use project or group access tokens—not personal access tokens—for service accounts. Follow the [Token Management Standard](/handbook/security/policies_and_standards/token-management-standard/), including its expiration and scope requirements.
   - Restrict CI job token access to an explicit [allowlist of authorized projects and groups](https://docs.gitlab.com/ci/jobs/ci_job_token/#add-a-group-or-project-to-the-job-token-allowlist). Use [fine-grained permissions](https://docs.gitlab.com/ci/jobs/fine_grained_permissions/) to grant each entry only the permissions it needs.

1. **Protect CI/CD variables.**
   - [Mask and hide](https://docs.gitlab.com/ci/variables/#cicd-variable-security) all CI/CD variables containing secrets or credentials, and [restrict those variables to protected branches](https://docs.gitlab.com/ci/variables/#protect-a-cicd-variable).
   - Set [**Minimum role to use pipeline variables**](https://docs.gitlab.com/ci/variables/#restrict-pipeline-variables) to **No one allowed** to prevent CI/CD variables being overridden in manually started pipelines.

1. <a id="pipeline-and-cicd-configurations"></a>**Verify CI dependencies.**
   - [Pin CI dependencies](/handbook/security/best-practices/supply-chain-security-for-dependencies/#supply-chain-security-best-practices) to fixed versions. Do not use moving references such as `latest`.
   - [Verify the integrity](/handbook/security/best-practices/supply-chain-security-for-dependencies/#supply-chain-security-best-practices) of packages, tools, and container images before using them in CI jobs. For signed images and artifacts, see [signature verification](https://docs.gitlab.com/ci/yaml/signing_examples/#verification).

1. **Run security scans.**
   - Run SAST, dependency scanning, and secret scanning in all merge request pipelines. See [security scanning in merge request pipelines](https://docs.gitlab.com/user/application_security/detect/security_configuration/#use-security-scanning-tools-with-merge-request-pipelines).
   - Enable [container scanning](https://docs.gitlab.com/user/application_security/container_scanning/) for all container images built from the default branch.
   - Enable [Infrastructure as Code scanning](https://docs.gitlab.com/user/application_security/iac_scanning/) to check all infrastructure-as-code changes for security misconfigurations.

1. **Enforce merge checks.**
   - Require passing CI pipelines before merging.
   - Configure [merge request approval policies](https://docs.gitlab.com/user/application_security/policies/merge_request_approval_policies/) to require approval for new High or Critical vulnerabilities detected by security scans, compared with the target branch.

1. **Protect published release tags.**
   - For any project that distributes software from release tags following semantic versioning (CI components, CLIs, packages, etc) restrict [protected tags](https://docs.gitlab.com/user/project/protected_tags/) to either Maintainer or to specific users or groups.

1. **Protect published packages.**
   - Before publishing a package to a public registry, check its contents against an approved list of permitted files or file patterns. For npm packages, follow the [package-content guidance](https://docs.gitlab.com/development/npmjs/#securing-package-metadata).
   - Configure [package protection rules](https://docs.gitlab.com/user/packages/package_registry/package_protection_rules/) to restrict who can push or delete packages, where supported.

1. **Protect production images and deployments.**
   - Restrict who can push, overwrite, or delete production images. Use [protected container tags](https://docs.gitlab.com/user/packages/container_registry/protected_container_tags/) for production tag patterns, or [protected container repositories](https://docs.gitlab.com/user/packages/container_registry/container_repository_protection_rules/) for repositories that hold only production images.
   - Configure [immutable container tags](https://docs.gitlab.com/user/packages/container_registry/immutable_container_tags/) for the semver version tags of production images, so no one can overwrite or delete them after they are published.
   - Configure [protected environments](https://docs.gitlab.com/ci/environments/protected_environments/) to restrict who can deploy to production.
   - Restrict production deployment jobs to protected branches. See [deployment-safety guidance](https://docs.gitlab.com/ci/environments/deployment_safety/).

For questions, ask in `#security-help`.

## Configuration examples

<a id="example-1-of-protected-branch-settings-configured-to-require-an-mr"></a>

### Protected branches

![Protected branch settings that require merge requests](/images/protected_branch_settings_example.jpg "Protected branch settings")

<a id="example-1-of-mr-approval-rules-configured-without-code-owners"></a>
<a id="example-2-of-mr-approval-rules-configured-with-code-owners"></a>

### Approval rules with Code Owners

![Merge request approval rules with Code Owners](/images/mr-approvals-with-code-owners.png "Approval rules with Code Owners")

### How the approval rules combine

When there isn't a Code Owner who can approve a file, GitLab [skips Code Owner approval](https://docs.gitlab.com/user/project/codeowners/troubleshooting/#approvals-shown-as-optional) for it. The **All eligible users** rule from [Require review and approval](#mr-approval-rule-configurations) stops that merge request from merging without a review.

For example, say `@alice` is the only Code Owner of `app.rb` and she leaves the project:

| All eligible users rule | Who approved | Can it merge? | Meets the baseline? |
|---|---|---|---|
| Off | Nobody | Yes, with no review | No |
| 1 approval | Nobody | No | Yes |
| 1 approval | Bob, who isn't the author | Yes | Yes |

These setups also make GitLab skip Code Owner approval for some files:

- **One person as the only owner of a path.** If they open the merge request, there's nobody left to approve it. Use a group with at least two direct members, invited to the project with at least the Developer role.
- **[`!` exclusions](https://docs.gitlab.com/user/project/codeowners/reference/#exclusion-patterns) or [optional `^` sections](https://docs.gitlab.com/user/project/codeowners/reference/#optional-sections)** on files that need review.
- **The catch-all `*` in a section with other lines.** GitLab uses the last line that matches a file, so `/docs/ @alice` below `*` makes `@alice` the only owner of `/docs/`. Keep `*` in its own section.

## Ongoing Monitoring

Please note that projects that meet the criteria for requiring baseline configurations may be selected at any point for testing of configurations by the [GitLab Security Compliance team](/handbook/security/security-assurance/security-compliance/) as part of our continuous control monitoring program to make sure we're adhering to the guidance outlined on this page. Please see the [GCF Security Control Lifecycle](/handbook/security/security-assurance/security-compliance/security-control-lifecycle/) page for an overview of the program.

Continuous control monitoring currently covers only the Protected Branch and MR Approval settings. Pipeline and CI/CD controls are not yet covered.

The Security Compliance team has also implemented live monitoring using [detections/alerts in the Devo SIEM tool](https://gitlab.com/gitlab-com/gl-security/security-operations/sirt/devo/-/tree/main/detections/secassurance?ref_type=heads) and Slack for all MR Approval and Protected Branch settings outlined above. If MRs were merged without proper approval/SOD in place as a result of the changed settings an [observation](/handbook/security/security-assurance/observation-management-procedure/) issue will be opened to identify the root cause and perform remediation. Remediation will include steps such as gaining an understanding of why they were changed, revert the settings back to being in compliance, and reviewing any MRs that were merged without proper approval or segregation of duties (SOD) in place to ensure no malicious changes were included obtaining retroactive approvals if needed. Security Compliance will also loop in the individual(s) who made the change as well as the management of the team that owns/works on the project in order to help identify the root cause of the changes and to work towards implementing workflow changes so that the settings do not need to be changed in order for teams to complete development work.

### Further Security Recommendations

1. Do not store variables in plaintext or rely on Masked environment variables for comprehensive secret management. Instead setup an [external secret storage solution](/handbook/security/external-secret-storage)
1. Strongly consider [creating a threat model](/handbook/security/product-security/security-platforms-architecture/application-security/threat-modeling/howto/) for the project.
1. Consider requesting an [AppSec review](/handbook/security/product-security/security-platforms-architecture/application-security/appsec-reviews/) when the project is more established.
1. Reach out to the AppSec team (`@gitlab-com/gl-security/appsec` and `#security_help`) for any further questions.

## References

- [GitLab Repositories](/handbook/engineering/workflow/gitlab-repositories/#creating-a-new-project) (for guidance on creating a new project)
- [Change Management Policy](/handbook/security/security-and-technology-policies/change-management-policy/)
- [GCF Security Control Lifecycle](/handbook/security/security-assurance/security-compliance/security-control-lifecycle/)
