---
title: ATO in Security program plan
description: The program plan for AI Transformation in the Security Division, including strategy, roles, operating rhythm, AI Champions, and timelines.
---

## Overview

The AI Transformation Owner (ATO) program in Security helps the Security Division adopt AI under one shared strategy, rather than each team taking a separate approach.

Security is one spoke in GitLab's [Hub & Spoke & Hub](/handbook/eta/ai/strategy/hub-and-spoke/) model for scaling AI. Responsibilities are split as follows:

- **Enterprise AI** owns the platform and how solutions are built.
- **The ATO** facilitates Security's AI roadmap, which defines what the division works on and why.
- **AI Champions** are a peer group within Security who shape the roadmap.

Use-case ideas go to the ATO through the AI Champions. Bugs, security issues, and platform feedback go directly to Enterprise AI.

### What the program includes

- **AI Champions:** a cross-team group of up to 10 people who shape Security's AI strategy and deliver outcomes.
- **AI office hours:** sessions every two weeks, open to anyone in Security.
- **AI patterns library:** standard AI tooling patterns, developed with input from each team (link to come).
- **Reporting:** a weekly update to the ATO Council and regular summaries for Security leadership.

The program is led by the Security ATO and coordinated by the Security Program Coordinator. See [Roles and owners](#roles-and-owners) for all roles and responsibilities.

### Getting help

- **Questions:** ask in AI office hours, post in `#enterprise-ai-collab`, or contact your team's AI Champion. You do not need to contact your AI Champion first.
- **Use-case ideas and requests:** share them with an AI Champion or in AI office hours. All requests are routed to the ATO.
- **Bugs, security issues, and platform feedback:** report them directly to Enterprise AI in `#ent-ai-champions` or through Serval.

### Guiding principles

- Strong security basics come first. AI-specific defenses add to them, not replace them.
- AI Champions are responsible for delivering outcomes, in addition to reporting status.
- Expectations are set realistically at the start of each effort.
- Patterns are developed jointly with the teams that use them.
- The ATO works through collaboration and does not direct teams.
- Before building something new, check what Enterprise AI and other teams have already delivered.

## Strategy

The AI Champions shape Security's AI strategy, and the ATO facilitates the process and stays accountable for it. The AI Champions set priorities, define practices, and choose which outcomes to pursue. The ATO convenes the group, removes blockers, and connects the work to Enterprise AI and the ATO Council.

The pillars below are a proposed starting point. The AI Champions can keep, change, or replace them at kickoff.

### Proposed guiding pillars

| Pillar | Description | Proposed measure |
| --- | --- | --- |
| Unify | One AI strategy and a shared set of tooling patterns across [Corporate Security](/handbook/security/corporate/), [Security Assurance](/handbook/security/security-assurance/), [Security Operations](/handbook/security/security-operations/), and [Product Security](/handbook/security/product-security/) | Patterns in the library are used by more than one team |
| Reduce toil | Use AI to reduce repetitive, manual security work | An agreed definition of toil, a baseline, and tracked reductions |
| Enable | Support adoption through AI Champions, office hours, and shared patterns | Office hours held on schedule; AI Champions active across teams |

Success is measured against Security's business metrics, and the ATO is accountable for them. Enterprise AI combines results across functions.

### Working practices

- The AI Champions agree on which outcomes to pursue before work begins.
- Security brings at least one update to each weekly ATO Council meeting.
- Teams redesign processes where appropriate, rather than adding AI to existing steps. See the [Guiding Principles](/handbook/eta/ai/strategy/guiding-principles/).

### Still to define

- Whether the AI Champions confirm, change, or replace the pillars
- Which Security business metrics each pillar affects, and the targets for each
- A shared definition of toil
- How progress is reported to the Security Division

## Roles and owners

| Role | Who | Responsibilities |
| --- | --- | --- |
| AI Transformation Owner (ATO) | Security ATO | Leads the AI Champions meeting and facilitates the AI Champions in shaping Security's AI strategy and roadmap; qualifies use cases; reviews builds within the division; reports results to the exec sponsor and the ATO Council |
| Program Coordinator | Security Program Coordinator | Facilitates meetings, tracks action items, compiles weekly updates, and manages the program schedule |
| AI Champions | Up to 10 nominees from across Security | Shape Security's AI strategy; deliver outcomes; contribute patterns; lead some AI Champions meetings |
| Security leaders | Vice presidents, directors, and managers | Nominate AI Champions and support their time commitment |
| Enterprise AI | Enterprise AI team | Owns the AI platform and its security: tooling, governance and security review (accountable platform reviewer with published SLAs), and cross-functional standards |
| Assigned AI Engineer | From Enterprise AI | Works with the ATO on solution design, prototypes, and production delivery; attends office hours |
| Exec sponsor | Chief Information Security Officer (CISO) | Executive sponsor for the program and escalation point for larger or cross-functional decisions |

## Operating rhythm

The program follows a recurring cycle. AI Champions meet weekly to work on the roadmap, the ATO reports weekly to the ATO Council, office hours run every two weeks for all of Security, and results are shared with the division. Questions raised in office hours can become topics for the AI Champions meeting.

### Recurring meetings

| Meeting | Cadence | Attendees | Purpose |
| --- | --- | --- | --- |
| AI Champions meeting | Weekly, 30 minutes (proposed) | ATO, AI Champions, Program Coordinator | Agree on outcomes, share progress, and resolve blockers |
| ATO Council update | Weekly | ATO | Report Security's AI progress, with at least one update each week |
| AI office hours | Every two weeks | Organized by the ATO; hosts to be confirmed; open to all of Security | Answer AI questions and identify common needs |
| AI Champions share-out | Monthly | Prepared by the ATO and AI Champions; shared with all of Security as a newsletter or post | Share work in progress and completed work across the division, with one-off demos as needed |
| Quarterly Business Review | Quarterly | Director of Enterprise AI, ATO, exec sponsor | Review delivered work and its value; discuss upcoming plans, dependencies, and requests |

Days and times are to be confirmed.

### Update process

1. AI Champions report progress at the weekly AI Champions meeting.
1. The Program Coordinator compiles the updates for the ATO Council.
1. The ATO presents the updates at the weekly ATO Council meeting.
1. Highlights are shared with the Security Division.

## AI Champions

AI Champions are a small group from across Security who shape the division's AI strategy, with the ATO as facilitator.

### Responsibilities

- Identify and qualify AI use cases within their team
- Pilot agents and workflows
- Coach teammates
- Report friction and feedback to the ATO
- Contribute to the shared AI patterns library
- Lead some AI Champions meetings when agreed with the ATO

AI Champions are expected to deliver outcomes, not only attend meetings.

AI Champions do not report to the ATO. The ATO connects them with Enterprise AI. Anyone in Security can bring questions to AI office hours without first contacting their AI Champion.

### Time commitment

AI Champions spend 5 to 10% of their time on the program. Each AI Champion agrees on this commitment with their manager.

### Selection process

1. The ATO shares the program goals with Security leaders.
1. Each leader nominates up to three people.
1. The final group is selected from the nominees and from known frequent AI users, balanced across teams. Each AI Champion's manager approves their participation.
1. The group has no more than 10 members.

### Availability changes

If an AI Champion's availability changes, their leader confirms whether they continue or nominates a replacement.

## Timeline and roadmap

All dates are proposed.

October covers setup: selecting the AI Champions, sending communications, and holding the kickoff the week of 2026-10-19, followed by a first 30-day cycle. During FY27-Q4 (2026-11-01 to 2027-01-31), the regular schedule begins, with the first AI office hours the week of 2026-11-02 and every two weeks after that.

### October setup

| Milestone | Target | Completion criteria | Owner |
| --- | --- | --- | --- |
| 1. Select the AI Champions | 2026-10-06 to 2026-10-16 | Nominations received from each direct report of the Chief Information Security Officer (CISO); managers approve the time commitment; time zones recorded | ATO, with the CISO's direct reports |
| 2. Send communications to the division | 2026-10-19 to 2026-10-30 | Division announcement sent; AI Champions Slack channel created; meeting and office hours invitations sent | Program Coordinator |
| 3. Kick off the program | Week of 2026-10-19 | Kickoff held; AI Champions confirm or revise the guiding pillars; weekly meeting begins | AI Champions, facilitated by the ATO |

### FY27-Q4 regular schedule

| Milestone | Target | Completion criteria | Owner |
| --- | --- | --- | --- |
| 4. AI office hours | Every two weeks from the week of 2026-11-02 | Six sessions held in FY27-Q4, open to all of Security | ATO |
| 5. Agree on the roadmap | 2026-11-02 to 2026-12-04 | AI Champions agree on a Security AI roadmap with priorities, sequence, and owners | AI Champions, facilitated by the ATO |

### FY27-Q4 office hours schedule

| Session | Week of | Notes |
| --- | --- | --- |
| 1 | 2026-11-02 | First session |
| 2 | 2026-11-16 | — |
| 3 | 2026-11-30 | — |
| 4 | 2026-12-14 | Last session of the calendar year |
| — | 2026-12-28 | No session (holidays) |
| 5 | 2027-01-11 | — |
| 6 | 2027-01-25 | Final FY27-Q4 session; input for the Quarterly Business Review |
