---
title: "Infrastructure Security"
description: "Infrastructure Security secures the cloud environments GitLab runs on, across commercial, corporate, and FedRAMP."
---

Infrastructure Security (InfraSec) is a team within [Product Security](/handbook/security/product-security/), part of the Platform Security group.

## Mission

We secure the cloud that GitLab's product and internal teams run on: commercial, corporate, and FedRAMP. We run the production security tooling that shows us our cloud posture, and we turn what it finds into fixes. We're also writing cloud, infrastructure, and data security requirements as controls that engineers and AI agents can both read, so secure configuration is built in from the start instead of caught in review.

## Scope and responsibilities

### What we own

1. **Cloud security requirements.** Cloud and infrastructure security requirements, written as machine-readable controls that plug into developer and AI coding workflows. This work lives in the GitLab Cloud Security Framework, which we're building now.
1. **Infrastructure security reviews.** AI-assisted reviews of features that add or change cloud infrastructure, containers, network architecture, infrastructure as code, or secrets management. We build and maintain the agents and flows behind these reviews.
1. **Production security tooling.** Running Wiz and our other security tools across GitLab's offerings, and feeding their findings into a steady remediation pipeline.
1. **Corporate cloud.** Securing our corporate cloud environments, including the Sandbox Cloud realm: access controls, cost governance, policy enforcement, and account lifecycle.
1. **Misconfiguration remediation.** Finding and fixing cloud misconfigurations in production and non-production environments.
1. **FedRAMP operations.** Moving off accelerator-provided tools toward one toolchain for Commercial and Federal, plus FedRAMP vulnerability management tooling, operations, and reporting.
1. **Data security.** Data-layer security requirements and remediation of data-layer risks, in production and non-production.
1. **Infrastructure penetration testing.** Coordinating pen tests of GitLab's cloud and production infrastructure.
1. **Risk register items.** Owning the cloud and data-layer items on the [Product Security Risk Register](/handbook/security/product-security/security-platforms-architecture/risk-register/) and leading their remediation.

### Out of scope

| Area | Who owns it |
|------|-------------|
| Application-layer security reviews | [Application Security](/handbook/security/product-security/security-platforms-architecture/application-security/) |
| Product-layer security architecture requirements | [Security Architecture](/handbook/security/product-security/security-platforms-architecture/security-architecture/) |
| Vulnerability management outside FedRAMP | [Vulnerability Operations](/handbook/security/product-security/vulnerability-management/) |
| Security controls for GitLab's own groups and namespaces, and software supply chain governance | Security Posture Management |

### Where our work comes from

Most of our work arrives through the request templates below. The rest comes from risk register items, FedRAMP and Security Compliance commitments, and the projects we plan each quarter.

## Working with us

1. To request an **infrastructure security review**, create an issue with [the security review template](https://gitlab.com/gitlab-com/gl-security/product-security/product-security-engagements/product-security-requests/-/issues/new?description_template=infrasec-security-review).
1. To request a **production readiness review**, create an issue with [the production readiness template](https://gitlab.com/gitlab-com/gl-security/product-security/product-security-engagements/product-security-requests/-/issues/new?description_template=infrasec-production-readiness).
1. To report a bug or request a change to **Teleport**, create an issue with [the Teleport template](https://gitlab.com/gitlab-com/gl-security/product-security/product-security-engagements/product-security-requests/-/issues/new?description_template=infrasec-teleport).
1. For anything else, use [the generic request template](https://gitlab.com/gitlab-com/gl-security/product-security/product-security-engagements/product-security-requests/-/issues/new?description_template=infrasec-other-request).

Please mention `@gitlab-com/gl-security/product-security/infrastructure-security` on GitLab instead of tagging individuals. On Slack, find us in `#security-infrasec` or tag `@infrasec-team`.

We triage new requests every working day. If something's urgent and can't wait, say so in `#security-infrasec`. For a security incident, don't wait for us: page the Security Incident Response Team with `/security` in any Slack channel.

## How we plan

We plan by quarter, and everything starts from the [FY27 InfraSec Planning epic (&210)](https://gitlab.com/groups/gitlab-com/gl-security/product-security/infrastructure-security/-/work_items/210). Each quarter has a planning epic and a KTLO/BAU epic underneath it. We link to the FY27 planning epic here rather than to the quarterly epics, because those change every quarter.

Our work falls into a few buckets:

- **Delivery epics** are planned projects. Each one has a lead and a named backup, a clear scope, and milestones written in the description.
- **Delivery issues** are smaller projects tracked as a single issue. If one grows, it gets an epic.
- **KTLO/BAU** is the recurring and reactive work: reviews, access grants, incident follow-up, renewals, and one-off tasks.
- **Paused work** stays visible in the quarter's planning epic, so nothing quietly disappears.

### Tracking KTLO and BAU work

When we pick up KTLO or BAU work, we add the issue as a child of the current quarter's KTLO/BAU epic, which sits under the [FY27 InfraSec Planning epic](https://gitlab.com/groups/gitlab-com/gl-security/product-security/infrastructure-security/-/work_items/210). If the issue already has a parent epic in another team's project, we link it to our KTLO/BAU epic as related instead of moving it.

This matters more than it looks. Reactive work is a big share of what we do, and the KTLO/BAU epic is the only place we can see and report on it. If it isn't linked, it didn't happen as far as planning is concerned.

### Prioritising KTLO and BAU work

There's more KTLO than we can do at once, so every item in the quarter's KTLO/BAU epic gets a priority label once we've reviewed it. Work from the top.

| Label | What it means |
|-------|---------------|
| `~priority::1` | Last-minute and critical. This should be rare |
| `~priority::2` | Prioritised and time-sensitive |
| `~priority::3` | Prioritised, but less time-sensitive |
| `~priority::4` | Reviewed, with no commitment yet. We pick these up once 1 to 3 are done |
| No priority label | Not reviewed yet |

Some areas have enough KTLO to get their own sub-epic under the quarter's KTLO/BAU epic, such as FedRAMP. The same labels apply there.

These labels are for planning our own work. Requests from other teams still go through [triage](issue-lifecycle/) first, and only get a priority label once we've added them to the KTLO/BAU epic.

### Labels

Delivery epics and delivery issues need both the team label and the current quarter label. The planning epic's queries use them to find active work, so anything missing either label won't show up.

| Label | Use it on |
|-------|-----------|
| `~"Infrastructure Security Team"` | All InfraSec work |
| `~"Department::Product Security"` | All InfraSec work |
| `~FY27-Q4` (the current quarter) | Delivery epics and delivery issues only. Don't add it to planning epics, KTLO/BAU epics, or KTLO/BAU items |
| `~priority::1` to `~priority::4` | KTLO/BAU items. See [Prioritising KTLO and BAU work](#prioritising-ktlo-and-bau-work) |
| `~"InfraSec::triage"` | New requests that need triage |

When delivery work carries into the next quarter, add the new quarter label and keep the old one as history.

### Project ownership

Each delivery epic's lead is responsible for delivering it. That means keeping the status and milestones in the epic description current, and moving issues along with the people working on them.

## Meetings

We work asynchronously by default, in our issues and epics. The team spans time zones from New Zealand to the US, so no single meeting time works for everyone.

Our team sync runs every week and rotates through three time slots, so everyone can make some of them without a midnight call. All three slots share one sync document, which holds the agenda and notes. Every session is recorded, with shortcuts to the recordings in the sync document and the InfraSec shared drive. When we miss a slot, we catch up on the recording and add to the agenda async.

Other team members are welcome to join. Get in touch with us in `#security-infrasec` and we'll add you to the invite and the agenda.

We also hold a quarterly retrospective on what went well and what to change, and each team member has regular 1:1s with their manager.

## Design documents

Before starting a new project, we encourage writing a design doc. It records the implementation approach and the key decisions, especially the trade-offs we weighed.

To propose a design:

1. Open an MR in the [InfraSec Team Charter repo](https://gitlab.com/gitlab-com/gl-security/product-security/infrastructure-security/team-charter/-/tree/main/designs), using [the design doc template](https://gitlab.com/gitlab-com/gl-security/product-security/infrastructure-security/team-charter/-/blob/main/.gitlab/issue_templates/design_doc.md) as a guide.
1. Fill in each section.
1. Add other team members as reviewers.
1. Link the MR from the delivery epic it belongs to.

## Who's on the team

We don't keep a list of names here, because it goes stale. For the current team:

- **Workday** shows who's on the team and who they report to.
- **Slack:** `@infrasec-team` reaches everyone, and `#security-infrasec` is where we work in the open.
- **GitLab:** the [Infrastructure Security group members list](https://gitlab.com/groups/gitlab-com/gl-security/product-security/infrastructure-security/-/group_members).
- **Role descriptions** are in the [job description library](/job-description-library/security/infrastructure-security).

## Team pages and resources

- The [Internal Handbook](https://internal.gitlab.com/handbook/security/product_security/infrastructure_security/) is our operational source of truth (GitLab team members only).
- The [Infrastructure Security subgroup](https://gitlab.com/gitlab-com/gl-security/product-security/infrastructure-security) holds our epics and repositories.
- The [Infrastructure Security public subgroup](https://gitlab.com/gitlab-com/gl-security/security-operations/infrastructure-security-public) holds public resources such as Docker images.
- [Teleport](teleport/) covers access to production resources.
- [Issue lifecycle](issue-lifecycle/) explains how the triage bot labels and closes issues.

### Onboarding

- Infrastructure Security [onboarding template](https://gitlab.com/gitlab-com/gl-security/product-security/infrastructure-security/team-charter/-/blob/master/onboarding/onboarding_template.md)
- [InfraSec entitlements template](https://gitlab.com/gitlab-com/team-member-epics/access-requests/-/blob/master/.gitlab/issue_templates/role_baseline_access_request_tasks/department_security/role_security_engineer_infrastructure_security.md)

## Keeping this page current

We review this page at the end of each quarter, as part of quarterly planning. If you spot something wrong before then, open an MR.
