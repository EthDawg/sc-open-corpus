---
title: "Security Awareness Training Standard"
description: "Security Training Standard"
controlled_document: true
tags:
  - security_standard
  - security_standard_at
---

{{< label name="Visibility: Audit" color="#E24329" >}}

## Purpose

Security Trainings and Awareness is key to ensuring that GitLab team members are continuously provided with user education activities and exercises about evolving threats, compliance obligations, and secure workplace practices in order to refine and improve their awareness.

## Scope

This standard applies to all GitLab team members, contractors/Temporary Service Providers (TSPs), consultants, vendors and other service providers that handle, manage, store or transmit GitLab data in support of GitLab's statutory, regulatory and contractual requirements.

### Definitions

- GitLab Team members: users with a gitlab.com email address
- Contractors/TSPs and Consultants: Personnel who are external to GitLab who do not have a gitlab.com email address and are under a contract/agreement that involves handling, managing, storing, or transmitting GitLab data in support of GitLab's statutory, regulatory and contractual requirements.

## Roles & Responsibilities

| Role | Responsibilities |
|------|----------|
| GitLab Team Members | Responsible for following the requirements of this standard |
| Security Governance Team | Responsible for the management and execution of security trainings and programs outlined in this standard |
| Security Governance Management | Responsible for oversight, escalation and approval of exceptions for this standard |
| Security Assurance Management (Code Owners) | Responsible for approving significant changes and exceptions to this standard |

## Standard

All GitLab Team members and contractors/TSPs are required to participate in GitLab's General Security Awareness Training, New Hire Training and on-going phishing simulations and training, or show evidence of equivalent training completion within the calendar year.  Security Trainings that require participation include the following:

### New Hire Security Training

[New Hire Security Training](/handbook/security/security-assurance/governance/sec-awareness-training/#when-will-security-awareness-training-occur) is required to be completed by all GitLab Team Members and contractors/TSPs during their onboarding at GitLab. This security training provides new hires with the knowledge to identify cybersecurity threats, vulnerabilities, and attacks.

### General Security Awareness Training (GSAT)

The GitLab [security awareness training program](/handbook/security/security-assurance/governance/sec-awareness-training/) provides ongoing training to GitLab team members that enhances knowledge and identification of cybersecurity threats, vulnerabilities, and attacks as well as satisfying external regulatory requirements. GitLab's handbook-first General Security Awareness Training is provided annually via Right Hand Cybersecurity, GitLab's third-party provider, and requires participation and completion by all GitLab Team Members and contractors/TSPs.

Exceptions during the active campaign will be made for GitLab team members on extended leave.

### Phishing Training

The GitLab [Phishing Training Program](/handbook/security/security-assurance/governance/phishing/) is designed to educate and evaluate GitLab's ability to detect and prevent phishing attempts.  Ongoing [phishing simulations and trainings](/handbook/security/security-assurance/governance/security-training/) are conducted once per quarter via Right Hand Cybersecurity, GitLab's third-party provider, and requires participation and completion by all assigned GitLab Team Members and contractors/TSPs.

Remember: If you see something, say something, and always report suspicious emails via [PhishArm](/handbook/security/security-assurance/governance/phishing/#what-to-do-if-you-suspect-an-email-is-a-phishing-attack).

### Secure Coding Training

The [GitLab Secure Coding Training](/handbook/security/secure-coding-training/) is a required training completed by a sub-group of GitLab Team Members and contractors/TSPs in the Engineering Department.  This training contains descriptions and [Secure Coding Guidelines](https://docs.gitlab.com/ee/development/secure_coding_guidelines.html) from OWASP (Open Web Application Security Project) addressing security vulnerabilities commonly identified in the GitLab codebase. This training is intended to help developers identify potential security vulnerabilities early, with the goal of reducing the number of vulnerabilities released over time.

Exceptions during the active campaign will be made for GitLab team members on extended leave.

### Other Security Trainings

As our Security Training Program matures, additional trainings will be identified and added.

## Exceptions

Exceptions to this procedure will be tracked as per the [Information Security Policy Exception Management Process](/handbook/security/controlled-document-procedure/#exceptions).

## References

- [Security Awareness Training Program](/handbook/security/security-assurance/governance/sec-awareness-training/)
- [Phishing Program](/handbook/security/security-assurance/governance/phishing/)
- [Data Classification Standard](/handbook/security/policies_and_standards/data-classification-standard/)
