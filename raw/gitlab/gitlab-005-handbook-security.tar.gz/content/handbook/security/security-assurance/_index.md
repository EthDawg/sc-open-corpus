---
title: "Security Assurance"
---

## <i class="fas fa-rocket"></i> Security Assurance Mission and Vision

Our mission is to provide a high level of assurance that GitLab (the platform and company) is secure.  

Our vision is to be a trusted sales enablement partner that is recognized internally and externally for its collaborative and transparent security assurance program, powered by AI and automation. This will be achieved through 10 strategic objectives:

1. Establish GitLab as a thought leader in DevSecOps and AI.
1. Accelerate the sales cycle to enable Sales to acquire new customers and reduce customer churn.
1. Align Security Assurance with strategic business objectives and develop oversight for continuous alignment
1. Enhance the efficiency and effectiveness of Security Assurance through automated and custom-built solutions
1. Facilitate strategic initiatives to expand and improve GitLab’s external Security brand.
1. Identify, manage, and reduce security risk through cross-functional collaboration, strategic prioritization, and proactive mitigation including governance over data security and resilience programs.
1. Proactive compliance initiatives to maintain competitive advantage and enable customer acquisition through alignment with regulatory and industry specific requirements.
1. Intra-division collaboration to enable successful, timely, and cost effective program and project initiation, management, and delivery through repeatable and scalable processes with consistent measurement and actionable reporting.
1. Influence product development and enhancement through deliberate use and delivery of actionable feedback.
1. Intra and Inter-division collaboration to enable effective and efficient identification and remediation of compliance findings.

## <i class="fas fa-tasks"></i> Security Assurance Department Structure

There are four teams in the Security Assurance department.

<table id="core-competencies">
  <tr>
    <th class="text-center">
        <i class="fas fa-hands-helping"></i>
        <h5>Governance & Field Security</h5>
    </th>
    <th class="text-center">
        <i class="fas fa-bullseye"></i>
        <h5>Security Compliance</h5>
    </th>
    <th class="text-center">
        <i class="fas fa-shield-alt"></i>
        <h5>Security Risk</h5>
    </th>

  </tr>
  <tr>
      <td>
        <ul>
            <li><a href="/handbook/security/security-assurance/governance/"> Governance Team Page </a></li>
            <li><a href="/handbook/security/security-assurance/field-security/"> Field Security Team Page </a></li>
        </ul>
      </td>
      <td>
        <ul>
            <li><a href="/handbook/security/security-assurance/security-compliance/"> Security Compliance Team Page </a></li>
        </ul>
      </td>
      <td>
        <ul>
            <li><a href="/handbook/security/security-assurance/security-risk/"> Security Risk Team Page </a></li>
        </ul>
      </td>

  </tr>
</table>

## <i class="fab fa-gitlab fa-fw" style="font-size:.85em" aria-hidden="true"></i> Core Competencies

### Field Security Core Competencies

- [Sales Training (Security)](/handbook/sales/onboarding/sqs-learning-objectives/)
- [Sales Enablement (Security)](/handbook/security/security-assurance/field-security/field-security-rfp/)
- [Customer Assurance (Security)](/handbook/security/security-assurance/field-security/customer-security-assessment-process/)
- [Security Evangelization](/handbook/security/security-assurance/field-security/evangelism/)

### Security Governance Core Competencies

- [Security Policies, Standards and Control maintenance](/handbook/security/controlled-document-procedure/)
- [Security Assurance Metrics](/handbook/security/security-assurance/governance/#security-assurance-metrics)
- [Regulatory Landscape Monitoring](/handbook/security/security-assurance/governance/#regulatory-and-compliance-landscape-monitoring)
- [Security Awareness and Training](/handbook/security/security-assurance/governance/sec-awareness-training/)
- [Security Assurance Application Administration](/handbook/security/security-assurance/#core-tools-and-systems)
- [Security Assurance Automation](/handbook/security/security-assurance/governance/security-assurance-automation/)

### Security Risk Core Competencies

- [Security Third Party Risk Management](/handbook/security/security-assurance/security-risk/third-party-risk-management/)
- [Tier 2 Operational Security Risk Management](/handbook/security/security-assurance/security-risk/storm-program/)
- [Business Impact Assessments](/handbook/security/security-assurance/security-risk/storm-program/business-impact-analysis/)
- [Critical System Tiering](/handbook/security/security-assurance/security-risk/storm-program/critical-systems/)

### Security Compliance Core Competencies

- [Continuous Control Monitoring](/handbook/security/security-assurance/security-compliance/sec-controls/)
- [Security Certifications and Attestations](../security-assurance/security-compliance/certifications/)
- [User Access Reviews (non-SOX)](/handbook/security/security-assurance/security-compliance/access-reviews/)
- [Observation management for control failures and Tier 3 (system-level) risks](/handbook/security/security-assurance/observation-management-procedure/)
- [Security Assurance System Intake](/handbook/security/security-assurance/security-compliance/sec-controls.md)

## <i class="far fa-newspaper"></i> Core Tools and Systems

The Security Assurance sub department utilizes a variety of tools to carry out day to day activities. The system admin is responsible for the following:

- Configuration changes
- Onboarding/offboarding/transfers (ie Access)
- Upgrades/patching/incidents
- Migrations to new environments
- Restores from backup
- Admin level audit evidence
- Quality oversight (limited scope)

All other actions are the responsibility of the assigned DRI.
See the internal handbook page [here](https://internal.gitlab.com/handbook/security/)

## <i class="fas fa-users"></i>Contacting the Team

- Join the #security-help slack channel and tag `@security-assurance`
- Email: <security-assurance@gitlab.com>

### Team READMEs

- [Byron's README](/handbook/security/readmes/byron-boots/)

## <i class="fas fa-book" style="color:rgb(110,73,203)" aria-hidden="true"></i> References

Check out these great security resources built with our customers in mind:

- GitLab's [Customer Assurance Package](https://trust.gitlab.com/)
- GitLab's [Security - Trust Center](https://about.gitlab.com/security/)
- GitLab's [Security Team Page](../_index.md)
