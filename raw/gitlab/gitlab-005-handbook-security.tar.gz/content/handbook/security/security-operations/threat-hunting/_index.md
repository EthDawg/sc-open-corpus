---
title: Threat Hunting Team
description: GitLab Threat Hunting Team Overview
---

## <i class="fas fa-rocket"></i> Our Vision

### Mission

Develop tools and techniques for identifying undetected compromises and platform abuse or exploitation and collaborate with partner teams to apply them to generate actionable findings.

### Scope

Threat hunting activities will include the GitLab corporate environment, the GitLab infrastructure, and the GitLab platform, including customer environments.

### Strategy

- Develop tools and techniques for advanced threat hunting capabilities.
- Engage in threat hunting activities based on identified areas of concern and areas of opportunity.
- Inform relevant partner teams of findings and collaborate on appropriate outcomes.

## <i class="fas fa-users"></i> The Team

### Team Members

| Name | Role |
|---|---|
| Matt Coons | [Senior Security Manager](/job-description-library/security/security-leadership/) |
| Sean Gillespie | [Staff Threat Hunting Engineer](/job-description-library/security/security-engineer/#staff-security-engineer) |

## <i class="fas fa-stream"></i> Services We Provide

1. Engineering
    - Developing tools and techniques for advanced threat hunting capabilities.
    - Assisting with deployment and configuration of security platforms associated with threat hunting capabilities.
1. Operational
    - Conducting threat hunting activities.
    - Researching attacker techniques to determine potential indicators.
    - Leveraging Threat Intelligence to detect emerging threats and document past findings.
1. Interrupt
    - Assisting partner teams with forensic and maintenance activities as needed.
