---
title: Apple macOS
description: "How CorpSec manages GitLab Macs with Fleet"
---

Every GitLab managed Mac enrolls in [Fleet](https://fleetdm.com/) for device management. Fleet also manages our [Linux](/handbook/security/corporate/systems/linux/) and Windows endpoints. GitLab Corporate services should not be accessed from a Mac that is not enrolled in Fleet.

## Requirements

| Requirement | Details |
| :--- | :--- |
| **Fleet Enrollment** | Mandatory for all Macs. See [Enroll your Mac](#enroll-your-mac). |
| **OS Version** | macOS 15 or later to enroll. Install updates by the deadline shown in the update notification. |
| **Full-Disk Encryption** | FileVault must be on. |
| **EDR Agent** | Installed automatically. Do not remove it. |
| **User Account** | Use the local account created during setup. |

## Check whether your Mac is enrolled

1. Click the Apple menu and open **System Settings**.
1. Select **General** > **Device Management**.
1. If a Fleet MDM profile is listed, your Mac is enrolled and no further action is needed. If **Device Management** is empty or not visible, follow [Enroll your Mac](#enroll-your-mac).

You can also look for the Fleet icon in the menu bar. Click it and select **My device** to see your Mac's status in Fleet, including any failing policies and how to fix them.

## Enroll your Mac

New Macs purchased through GitLab enroll during Setup Assistant when you click **Enroll** on the **Device Management** screen and sign in with Okta. Follow the [Mac setup steps in Onboarding 101](/handbook/eta/corporate-it/end-user-services/onboarding101/#mac-setup), which also apply to replacement Macs and Macs that IT has wiped.

If the **Device Management** screen does not appear during setup, your Mac is not assigned to Fleet. Use [manual enrollment](/handbook/eta/corporate-it/end-user-services/onboarding101/#manual-mac-setup) instead.

## Additional resources

- [Laptop Security Configuration Standards](/handbook/eta/corporate-it/end-user-services/laptop-management/laptop-security/)
- [Laptop Wipe (Factory Reset) Process](/handbook/eta/corporate-it/end-user-services/laptop-management/laptop-wipe/)
