---
title: Technical Discovery
---

## Key Links

- [SA Modern Apps Discovery Process & Guide](https://docs.google.com/document/d/11-o9oTxSLomBoOTerGnfj3HXzXbouZ2p6yuIfXuJweQ/edit?ts=5ff6441b#heading=h.4b6ktib5prk9)
